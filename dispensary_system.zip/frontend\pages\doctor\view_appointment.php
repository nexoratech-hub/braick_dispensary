<?php
// ================================================================
// FILE: frontend/pages/doctor/view_appointment.php
// DOCTOR - VIEW APPOINTMENT DETAILS WITH VITAL SIGNS
// USING NEW DATABASE: dispensary_db
// Session-based login (NO BYPASS)
// BRAICK DISPENSARY
// ================================================================

session_start();

// ================================================================
// CHECK SESSION - REDIRECT TO LOGIN IF NOT DOCTOR
// ================================================================
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'doctor') {
    header('Location: /dispensary_system/frontend/pages/login.php');
    exit;
}

// ================================================================
// GET DOCTOR DATA FROM SESSION
// ================================================================
$doctor_id = $_SESSION['user_id'];
$doctor_name = $_SESSION['full_name'] ?? 'Dr. Unknown';
$doctor_branch_id = $_SESSION['branch_id'] ?? 1;
$doctor_specialty = $_SESSION['specialty'] ?? 'General Medicine';
$profile_pic = $_SESSION['profile_pic'] ?? '';
$is_online = $_SESSION['is_online'] ?? 0;

// ================================================================
// GET APPOINTMENT ID
// ================================================================
$appointment_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($appointment_id <= 0) {
    header('Location: appointments.php?error=invalid_id');
    exit;
}

// ================================================================
// INCLUDE DATABASE
// ================================================================
require_once __DIR__ . '/../../../backend/config/database.php';

try {
    $db = Database::getInstance()->getConnection();
} catch (Exception $e) {
    die("Database connection failed: " . $e->getMessage());
}

// ================================================================
// VERIFY DOCTOR EXISTS AND IS ACTIVE
// ================================================================
try {
    $stmt = $db->prepare("SELECT id, full_name, branch_id, specialty, profile_pic, status, is_online FROM users WHERE id = ? AND role = 'doctor'");
    $stmt->execute([$doctor_id]);
    $doctor_data = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$doctor_data || $doctor_data['status'] !== 'active') {
        session_destroy();
        header('Location: /dispensary_system/frontend/pages/login.php');
        exit;
    }
    
    $doctor_name = $doctor_data['full_name'];
    $doctor_branch_id = $doctor_data['branch_id'] ?? 1;
    $doctor_specialty = $doctor_data['specialty'] ?? 'General Medicine';
    $profile_pic = $doctor_data['profile_pic'] ?? '';
    $is_online = $doctor_data['is_online'] ?? 0;
    
    $_SESSION['full_name'] = $doctor_name;
    $_SESSION['branch_id'] = $doctor_branch_id;
    $_SESSION['specialty'] = $doctor_specialty;
    $_SESSION['profile_pic'] = $profile_pic;
    $_SESSION['is_online'] = $is_online;
    
} catch (Exception $e) {
    error_log("view_appointment verification error: " . $e->getMessage());
}

// ================================================================
// GET APPOINTMENT DETAILS - Verify doctor has access
// ================================================================
try {
    $stmt = $db->prepare("
        SELECT 
            a.*,
            p.id as patient_id,
            p.full_name as patient_name,
            p.patient_id as patient_code,
            p.phone as patient_phone,
            p.email as patient_email,
            p.date_of_birth,
            p.gender,
            p.address,
            p.blood_group,
            p.allergies,
            u.full_name as doctor_name,
            u.specialty as doctor_specialty,
            r.full_name as created_by_name,
            b.name as branch_name
        FROM appointments a
        JOIN patients p ON a.patient_id = p.id
        LEFT JOIN users u ON a.doctor_id = u.id
        LEFT JOIN users r ON a.created_by = r.id
        LEFT JOIN branches b ON a.branch_id = b.id
        WHERE a.id = ? AND a.doctor_id = ?
    ");
    $stmt->execute([$appointment_id, $doctor_id]);
    $appointment = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$appointment) {
        header('Location: appointments.php?error=not_found');
        exit;
    }
} catch (Exception $e) {
    error_log("Appointment fetch error: " . $e->getMessage());
    header('Location: appointments.php?error=database_error');
    exit;
}

// ================================================================
// GET VITAL SIGNS FOR THIS APPOINTMENT
// ================================================================
$vital_signs = null;
try {
    $stmt = $db->prepare("
        SELECT vs.*, u.full_name as recorded_by_name
        FROM vital_signs vs
        LEFT JOIN users u ON vs.recorded_by = u.id
        WHERE vs.appointment_id = ?
        ORDER BY vs.recorded_at DESC
        LIMIT 1
    ");
    $stmt->execute([$appointment_id]);
    $vital_signs = $stmt->fetch(PDO::FETCH_ASSOC);

    // If no vital signs for this appointment, try to get latest for patient
    if (!$vital_signs && isset($appointment['patient_id'])) {
        $stmt = $db->prepare("
            SELECT vs.*, u.full_name as recorded_by_name
            FROM vital_signs vs
            LEFT JOIN users u ON vs.recorded_by = u.id
            WHERE vs.patient_id = ?
            ORDER BY vs.recorded_at DESC
            LIMIT 1
        ");
        $stmt->execute([$appointment['patient_id']]);
        $vital_signs = $stmt->fetch(PDO::FETCH_ASSOC);
    }
} catch (Exception $e) {
    $vital_signs = null;
}

// ================================================================
// GET DOCTOR'S BRANCH NAME
// ================================================================
$doctor_branch_name = 'Not Assigned';
try {
    $stmt = $db->prepare("SELECT name FROM branches WHERE id = ? AND status = 'active'");
    $stmt->execute([$doctor_branch_id]);
    $branch_data = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($branch_data) {
        $doctor_branch_name = $branch_data['name'];
    }
} catch (Exception $e) {
    $doctor_branch_name = 'Branch';
}

// ================================================================
// GET UNREAD NOTIFICATIONS COUNT
// ================================================================
$unread_notifications = 0;
try {
    $stmt = $db->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0");
    $stmt->execute([$doctor_id]);
    $unread_notifications = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
} catch (Exception $e) {
    $unread_notifications = 0;
}

// ================================================================
// FUNCTIONS
// ================================================================
function getStatusBadgeClass($status) {
    switch ($status) {
        case 'completed': return 'badge-success';
        case 'confirmed': return 'badge-info';
        case 'cancelled': return 'badge-danger';
        case 'scheduled': return 'badge-warning';
        case 'pending': return 'badge-warning';
        default: return 'badge-warning';
    }
}

function calculateAge($dob) {
    if (empty($dob) || $dob === '0000-00-00') return 'N/A';
    $birthDate = new DateTime($dob);
    $today = new DateTime('today');
    $age = $birthDate->diff($today)->y;
    return $age;
}

// ================================================================
// INCLUDE HEADER & SIDEBAR
// ================================================================
include_once __DIR__ . '/../../components/doctor_header.php';
include_once __DIR__ . '/../../components/doctor_sidebar.php';
?>

<!-- ================================================================ -->
<!-- MAIN CONTENT -->
<!-- ================================================================ -->
<main class="main-content">

    <!-- Page Header -->
    <div class="page-header flex flex-wrap justify-between items-center gap-3 mb-6">
        <div>
            <h1 class="page-title">
                <i class="fas fa-calendar-check mr-2" style="color: #0B5ED7;"></i> Appointment Details
            </h1>
            <p class="page-subtitle">
                View complete appointment information with vital signs
                <span class="branch-tag ml-2">
                    <i class="fas fa-store-alt"></i> <?= htmlspecialchars($doctor_branch_name) ?>
                </span>
                <span class="ml-2 inline-flex bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-xs border border-blue-200">
                    <i class="fas fa-hashtag mr-1"></i> Appointment #<?= $appointment['id'] ?>
                </span>
                <span class="ml-2 inline-flex bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs border border-green-200">
                    <i class="fas fa-user mr-1"></i> <?= htmlspecialchars($appointment['patient_name']) ?>
                </span>
                <span class="ml-2 inline-flex bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-xs border border-blue-200">
                    <i class="fas fa-user-md mr-1"></i> Dr. <?= htmlspecialchars($doctor_name) ?>
                </span>
            </p>
        </div>
        <div class="flex gap-2 flex-wrap">
            <a href="appointments.php" class="btn btn-outline btn-sm">
                <i class="fas fa-arrow-left"></i> Back
            </a>
            <?php if (($appointment['status'] ?? '') === 'scheduled' || ($appointment['status'] ?? '') === 'pending'): ?>
                <a href="confirm_appointment.php?id=<?= $appointment['id'] ?>" class="btn btn-success btn-sm" onclick="return confirm('Confirm this appointment?')">
                    <i class="fas fa-check"></i> Confirm
                </a>
                <a href="cancel_appointment.php?id=<?= $appointment['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Cancel this appointment?')">
                    <i class="fas fa-times"></i> Cancel
                </a>
            <?php endif; ?>
            <?php if (($appointment['status'] ?? '') === 'confirmed'): ?>
                <a href="complete_appointment.php?id=<?= $appointment['id'] ?>" class="btn btn-success btn-sm" onclick="return confirm('Mark this appointment as completed?')">
                    <i class="fas fa-check-double"></i> Complete
                </a>
            <?php endif; ?>
            <button onclick="window.print()" class="btn btn-outline btn-sm">
                <i class="fas fa-print"></i> Print
            </button>
        </div>
    </div>

    <!-- ================================================================ -->
    <!-- APPOINTMENT SUMMARY -->
    <!-- ================================================================ -->
    <div class="summary-header">
        <div class="summary-header-left">
            <h2 class="summary-title">
                <?= htmlspecialchars($appointment['patient_name']) ?>
                <span class="status-badge <?= getStatusBadgeClass($appointment['status']) ?>">
                    <?= ucfirst($appointment['status'] ?? 'Scheduled') ?>
                </span>
            </h2>
            <div class="summary-meta">
                <span class="meta-item">
                    <i class="far fa-calendar-alt"></i>
                    <?= date('F d, Y', strtotime($appointment['appointment_date'])) ?>
                </span>
                <span class="meta-item">
                    <i class="far fa-clock"></i>
                    <?= date('h:i A', strtotime($appointment['appointment_date'])) ?>
                </span>
                <span class="meta-item">
                    <i class="fas fa-user-md"></i>
                    Doctor: <?= htmlspecialchars($appointment['doctor_name'] ?? $doctor_name) ?>
                </span>
                <span class="meta-item">
                    <i class="fas fa-venus-mars"></i>
                    <?= htmlspecialchars($appointment['gender'] ?? 'N/A') ?>
                </span>
                <span class="meta-item">
                    <i class="fas fa-calendar-alt"></i>
                    Age: <?= calculateAge($appointment['date_of_birth'] ?? '') ?> years
                </span>
            </div>
        </div>
        <div class="summary-header-right">
            <span class="appointment-id">#<?= $appointment['id'] ?></span>
            <span class="created-by">
                <i class="fas fa-user-plus"></i>
                Created by: <?= htmlspecialchars($appointment['created_by_name'] ?? 'N/A') ?>
            </span>
        </div>
    </div>

    <!-- ================================================================ -->
    <!-- VITAL SIGNS SECTION - 6 SIGNS -->
    <!-- ================================================================ -->
    <div class="vital-signs-container">
        <div class="vital-signs-header">
            <h3 class="vital-signs-title">
                <i class="fas fa-heartbeat"></i> 6 Vital Signs
                <?php if ($vital_signs): ?>
                    <span class="vital-recorded">
                        <i class="fas fa-check-circle"></i> 
                        Recorded: <?= date('d/m/Y H:i', strtotime($vital_signs['recorded_at'])) ?>
                        <?php if ($vital_signs['recorded_by_name']): ?>
                            by <?= htmlspecialchars($vital_signs['recorded_by_name']) ?>
                        <?php endif; ?>
                    </span>
                <?php else: ?>
                    <span class="vital-not-recorded">
                        <i class="fas fa-clock"></i> Not recorded yet
                    </span>
                <?php endif; ?>
            </h3>
            <?php if (!$vital_signs): ?>
                <a href="add_vital_signs.php?appointment=<?= $appointment['id'] ?>&patient=<?= $appointment['patient_id'] ?>" class="btn btn-primary btn-sm">
                    <i class="fas fa-plus"></i> Add Vital Signs
                </a>
            <?php endif; ?>
        </div>
        
        <div class="vital-signs-grid">
            
            <!-- 1. Blood Pressure -->
            <div class="vital-item">
                <div class="vital-icon">💓</div>
                <div class="vital-value">
                    <?php if ($vital_signs && isset($vital_signs['blood_pressure_systolic']) && isset($vital_signs['blood_pressure_diastolic'])): ?>
                        <?= $vital_signs['blood_pressure_systolic'] ?>/<?= $vital_signs['blood_pressure_diastolic'] ?>
                    <?php else: ?>
                        —
                    <?php endif; ?>
                </div>
                <div class="vital-label">Blood Pressure</div>
                <div class="vital-unit">mmHg</div>
                <div class="vital-normal">Normal: 120/80</div>
            </div>
            
            <!-- 2. Temperature -->
            <div class="vital-item">
                <div class="vital-icon">🌡️</div>
                <div class="vital-value">
                    <?php if ($vital_signs && isset($vital_signs['temperature'])): ?>
                        <?= $vital_signs['temperature'] ?>°
                    <?php else: ?>
                        —
                    <?php endif; ?>
                </div>
                <div class="vital-label">Temperature</div>
                <div class="vital-unit">Celsius</div>
                <div class="vital-normal">Normal: 36.5 - 37.5</div>
            </div>
            
            <!-- 3. Pulse Rate -->
            <div class="vital-item">
                <div class="vital-icon">❤️</div>
                <div class="vital-value">
                    <?php if ($vital_signs && isset($vital_signs['pulse_rate'])): ?>
                        <?= $vital_signs['pulse_rate'] ?>
                    <?php else: ?>
                        —
                    <?php endif; ?>
                </div>
                <div class="vital-label">Pulse Rate</div>
                <div class="vital-unit">bpm</div>
                <div class="vital-normal">Normal: 60 - 100</div>
            </div>
            
            <!-- 4. Weight -->
            <div class="vital-item">
                <div class="vital-icon">⚖️</div>
                <div class="vital-value">
                    <?php if ($vital_signs && isset($vital_signs['weight'])): ?>
                        <?= $vital_signs['weight'] ?>
                    <?php else: ?>
                        —
                    <?php endif; ?>
                </div>
                <div class="vital-label">Weight</div>
                <div class="vital-unit">kg</div>
                <div class="vital-normal">Recorded</div>
            </div>
            
            <!-- 5. Height -->
            <div class="vital-item">
                <div class="vital-icon">📏</div>
                <div class="vital-value">
                    <?php if ($vital_signs && isset($vital_signs['height'])): ?>
                        <?= $vital_signs['height'] ?>
                    <?php else: ?>
                        —
                    <?php endif; ?>
                </div>
                <div class="vital-label">Height</div>
                <div class="vital-unit">cm</div>
                <div class="vital-normal">Recorded</div>
            </div>
            
            <!-- 6. BMI (Auto-calculated) -->
            <div class="vital-item bmi-item">
                <div class="vital-icon">📊</div>
                <div class="vital-value">
                    <?php if ($vital_signs && isset($vital_signs['bmi'])): ?>
                        <?= $vital_signs['bmi'] ?>
                    <?php else: ?>
                        —
                    <?php endif; ?>
                </div>
                <div class="vital-label">BMI</div>
                <div class="vital-unit">kg/m²</div>
                <?php if ($vital_signs && isset($vital_signs['bmi'])): ?>
                    <?php 
                        $bmi = $vital_signs['bmi'];
                        $category = 'Normal';
                        $color = '#059669';
                        if ($bmi < 18.5) { $category = 'Underweight'; $color = '#D97706'; }
                        elseif ($bmi < 25) { $category = 'Normal'; $color = '#059669'; }
                        elseif ($bmi < 30) { $category = 'Overweight'; $color = '#D97706'; }
                        else { $category = 'Obese'; $color = '#DC2626'; }
                    ?>
                    <div class="vital-category" style="color:<?= $color ?>;"><?= $category ?></div>
                <?php else: ?>
                    <div class="vital-normal">Normal: 18.5 - 24.9</div>
                <?php endif; ?>
            </div>
            
        </div>
        
        <!-- Vital Signs Notes -->
        <?php if ($vital_signs && !empty($vital_signs['notes'])): ?>
            <div class="vital-notes">
                <div class="vital-notes-label">📝 Notes:</div>
                <div class="vital-notes-text"><?= htmlspecialchars($vital_signs['notes']) ?></div>
            </div>
        <?php endif; ?>
    </div>

    <!-- ================================================================ -->
    <!-- APPOINTMENT & PATIENT INFO -->
    <!-- ================================================================ -->
    <div class="info-grid">
        <div class="info-card">
            <h4 class="info-card-title">
                <i class="fas fa-calendar-check text-blue-600"></i> Appointment Information
            </h4>
            <div class="info-card-body">
                <div class="info-row">
                    <span class="info-label">Appointment Date</span>
                    <span class="info-value font-semibold"><?= date('F d, Y', strtotime($appointment['appointment_date'])) ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Appointment Time</span>
                    <span class="info-value"><?= date('h:i A', strtotime($appointment['appointment_date'])) ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Visit Type</span>
                    <span class="info-value"><?= ucfirst($appointment['visit_type'] ?? 'New') ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Purpose</span>
                    <span class="info-value"><?= htmlspecialchars($appointment['purpose'] ?? 'Not specified') ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Status</span>
                    <span class="info-value">
                        <span class="badge <?= getStatusBadgeClass($appointment['status']) ?>">
                            <?= ucfirst($appointment['status'] ?? 'Scheduled') ?>
                        </span>
                    </span>
                </div>
                <div class="info-row">
                    <span class="info-label">Doctor</span>
                    <span class="info-value"><?= htmlspecialchars($appointment['doctor_name'] ?? $doctor_name) ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Specialty</span>
                    <span class="info-value"><?= htmlspecialchars($appointment['doctor_specialty'] ?? 'General Practitioner') ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Branch</span>
                    <span class="info-value"><?= htmlspecialchars($appointment['branch_name'] ?? $doctor_branch_name) ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Created By</span>
                    <span class="info-value"><?= htmlspecialchars($appointment['created_by_name'] ?? 'N/A') ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Created On</span>
                    <span class="info-value"><?= date('F d, Y h:i A', strtotime($appointment['created_at'])) ?></span>
                </div>
            </div>
        </div>

        <div class="info-card">
            <h4 class="info-card-title">
                <i class="fas fa-user text-green-600"></i> Patient Information
            </h4>
            <div class="info-card-body">
                <div class="info-row">
                    <span class="info-label">Full Name</span>
                    <span class="info-value font-semibold"><?= htmlspecialchars($appointment['patient_name']) ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Patient ID</span>
                    <span class="info-value font-mono"><?= htmlspecialchars($appointment['patient_code'] ?? 'N/A') ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Gender</span>
                    <span class="info-value"><?= htmlspecialchars($appointment['gender'] ?? 'N/A') ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Date of Birth</span>
                    <span class="info-value"><?= !empty($appointment['date_of_birth']) && $appointment['date_of_birth'] !== '0000-00-00' ? date('M d, Y', strtotime($appointment['date_of_birth'])) : 'N/A' ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Age</span>
                    <span class="info-value"><?= calculateAge($appointment['date_of_birth'] ?? '') ?> years</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Phone</span>
                    <span class="info-value"><?= htmlspecialchars($appointment['patient_phone'] ?? 'N/A') ?></span>
                </div>
                <?php if (!empty($appointment['patient_email'])): ?>
                    <div class="info-row">
                        <span class="info-label">Email</span>
                        <span class="info-value"><?= htmlspecialchars($appointment['patient_email']) ?></span>
                    </div>
                <?php endif; ?>
                <?php if (!empty($appointment['blood_group'])): ?>
                    <div class="info-row">
                        <span class="info-label">Blood Group</span>
                        <span class="info-value"><?= htmlspecialchars($appointment['blood_group']) ?></span>
                    </div>
                <?php endif; ?>
                <?php if (!empty($appointment['allergies'])): ?>
                    <div class="info-row">
                        <span class="info-label">Allergies</span>
                        <span class="info-value"><?= htmlspecialchars($appointment['allergies']) ?></span>
                    </div>
                <?php endif; ?>
                <?php if (!empty($appointment['address'])): ?>
                    <div class="info-row">
                        <span class="info-label">Address</span>
                        <span class="info-value"><?= htmlspecialchars($appointment['address']) ?></span>
                    </div>
                <?php endif; ?>
                <?php if (!empty($appointment['notes'])): ?>
                    <div class="info-row">
                        <span class="info-label">Notes</span>
                        <span class="info-value"><?= htmlspecialchars($appointment['notes']) ?></span>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <p>
            <span class="footer-brand">Braick Dispensary</span> Management System
            <span class="text-gray-300 mx-2">|</span>
            Appointment Details with Vital Signs
            <span class="text-gray-300 mx-2">|</span>
            Dr. <?= htmlspecialchars($doctor_name) ?>
            <span class="text-gray-300 mx-2">|</span>
            &copy; <?= date('Y') ?> All rights reserved
        </p>
    </footer>

</main>

<!-- ================================================================ -->
<!-- TOAST -->
<!-- ================================================================ -->
<div id="toast" class="toast-custom" style="display:none;">
    <i class="fas fa-info-circle"></i>
    <div>
        <p id="toastTitle">Notification</p>
        <p id="toastMessage"></p>
    </div>
</div>

<!-- ================================================================ -->
<!-- STYLES (ALL STYLES INCLUDED) -->
<!-- ================================================================ -->
<style>
    /* ================================================================
       ROOT VARIABLES - LIGHT & DARK MODE
       ================================================================ */
    :root {
        --primary: #0B5ED7;
        --primary-dark: #0A4CA8;
        --primary-light: #6EA8FE;
        --primary-bg: #E8F0FE;
        --success: #059669;
        --success-dark: #047857;
        --success-light: #34D399;
        --success-bg: #D1FAE5;
        --danger: #DC2626;
        --danger-dark: #B91C1C;
        --danger-light: #F87171;
        --danger-bg: #FEE2E2;
        --warning: #D97706;
        --warning-bg: #FEF3C7;
        --purple: #7C3AED;
        --purple-bg: #EDE9FE;
        --white: #FFFFFF;
        --gray-50: #F8FAFC;
        --gray-100: #F1F5F9;
        --gray-200: #E2E8F0;
        --gray-300: #CBD5E1;
        --gray-400: #94A3B8;
        --gray-500: #64748B;
        --gray-600: #475569;
        --gray-700: #334155;
        --gray-800: #1E293B;
        --gray-900: #0F172A;
        --bg-body: #F1F5F9;
        --bg-card: #FFFFFF;
        --bg-nav: #FFFFFF;
        --text-primary: #1E293B;
        --text-secondary: #64748B;
        --border-color: #E2E8F0;
        --shadow: 0 1px 3px rgba(0,0,0,0.08);
        --shadow-md: 0 4px 12px rgba(0,0,0,0.07);
        --shadow-lg: 0 8px 25px rgba(0,0,0,0.1);
    }
    
    [data-theme="dark"] {
        --bg-body: #0F172A;
        --bg-card: #1E293B;
        --bg-nav: #1E293B;
        --text-primary: #F1F5F9;
        --text-secondary: #94A3B8;
        --border-color: #334155;
        --shadow: 0 1px 3px rgba(0,0,0,0.3);
        --shadow-md: 0 4px 12px rgba(0,0,0,0.3);
        --shadow-lg: 0 8px 25px rgba(0,0,0,0.4);
    }
    
    /* ================================================================
       BASE
       ================================================================ */
    * { margin: 0; padding: 0; box-sizing: border-box; }
    
    body {
        font-family: 'Inter', 'Segoe UI', -apple-system, sans-serif;
        background: var(--bg-body);
        color: var(--text-primary);
        transition: background 0.3s ease, color 0.3s ease;
    }
    
    .main-content {
        margin-left: 270px;
        margin-top: 68px;
        padding: 24px 28px;
        min-height: calc(100vh - 68px);
        background: var(--bg-body);
        color: var(--text-primary);
        transition: all 0.3s ease;
    }
    
    ::-webkit-scrollbar { width: 5px; height: 5px; }
    ::-webkit-scrollbar-track { background: var(--bg-body); }
    ::-webkit-scrollbar-thumb { background: var(--primary); border-radius: 10px; }
    
    /* ================================================================
       PAGE HEADER
       ================================================================ */
    .page-header {
        border-bottom: 3px solid var(--primary);
        padding-bottom: 12px;
        margin-bottom: 20px;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        align-items: center;
        gap: 12px;
    }
    
    .page-header .page-title {
        color: var(--primary-dark);
        font-size: 1.8rem;
        font-weight: 700;
    }
    
    [data-theme="dark"] .page-header .page-title {
        color: var(--primary-light);
    }
    
    .page-header .page-subtitle {
        color: var(--text-secondary);
        font-size: 0.9rem;
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 6px;
    }
    
    .branch-tag {
        background: #059669;
        color: white;
        padding: 3px 14px;
        border-radius: 20px;
        font-size: 0.7rem;
        font-weight: 600;
        display: inline-flex;
        align-items: center;
        gap: 4px;
    }
    
    /* ================================================================
       SUMMARY HEADER
       ================================================================ */
    .summary-header {
        background: var(--bg-card);
        border-radius: 16px;
        padding: 24px 28px;
        border: 2px solid var(--border-color);
        margin-bottom: 24px;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        align-items: flex-start;
        gap: 16px;
        transition: all 0.3s ease;
    }
    
    .summary-header:hover {
        border-color: var(--primary);
        box-shadow: var(--shadow-md);
    }
    
    .summary-title {
        font-size: 1.4rem;
        font-weight: 700;
        color: var(--text-primary);
        margin: 0 0 6px 0;
        display: flex;
        align-items: center;
        gap: 12px;
        flex-wrap: wrap;
    }
    
    .summary-meta {
        display: flex;
        flex-wrap: wrap;
        gap: 16px;
    }
    
    .meta-item {
        font-size: 0.8rem;
        color: var(--text-secondary);
        display: flex;
        align-items: center;
        gap: 6px;
    }
    
    .meta-item i {
        font-size: 0.8rem;
        color: var(--primary);
    }
    
    .summary-header-right {
        display: flex;
        flex-direction: column;
        align-items: flex-end;
        gap: 4px;
    }
    
    .appointment-id {
        font-size: 0.9rem;
        font-weight: 700;
        color: var(--primary);
        font-family: monospace;
    }
    
    .created-by {
        font-size: 0.75rem;
        color: var(--text-secondary);
        display: flex;
        align-items: center;
        gap: 4px;
    }
    
    .status-badge {
        padding: 4px 16px;
        border-radius: 20px;
        font-size: 0.85rem;
        font-weight: 600;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        color: white;
        border: none;
    }
    
    .status-badge.badge-success { background: #059669; }
    .status-badge.badge-danger { background: #EF4444; }
    .status-badge.badge-warning { background: #D97706; }
    .status-badge.badge-info { background: var(--primary); }
    
    /* ================================================================
       VITAL SIGNS SECTION
       ================================================================ */
    .vital-signs-container {
        background: var(--bg-card);
        border-radius: 16px;
        padding: 20px 24px;
        border: 2px solid var(--border-color);
        margin-bottom: 24px;
        transition: all 0.3s ease;
    }
    
    .vital-signs-container:hover {
        border-color: var(--primary);
        box-shadow: var(--shadow-md);
    }
    
    .vital-signs-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 2px solid var(--border-color);
        padding-bottom: 12px;
        margin-bottom: 16px;
        flex-wrap: wrap;
        gap: 8px;
    }
    
    .vital-signs-title {
        font-size: 1rem;
        font-weight: 700;
        color: var(--text-primary);
        display: flex;
        align-items: center;
        gap: 10px;
        margin: 0;
    }
    
    .vital-signs-title i {
        color: #DC2626;
    }
    
    .vital-recorded {
        font-size: 0.7rem;
        font-weight: 500;
        color: #059669;
        display: inline-flex;
        align-items: center;
        gap: 4px;
    }
    
    .vital-not-recorded {
        font-size: 0.7rem;
        font-weight: 500;
        color: var(--text-secondary);
        display: inline-flex;
        align-items: center;
        gap: 4px;
    }
    
    .vital-signs-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 16px;
    }
    
    .vital-item {
        background: var(--bg-body);
        border-radius: 12px;
        padding: 16px 18px;
        text-align: center;
        border: 2px solid var(--border-color);
        transition: all 0.3s ease;
    }
    
    .vital-item:hover {
        border-color: var(--primary);
        transform: translateY(-2px);
        box-shadow: var(--shadow-md);
    }
    
    .vital-item .vital-icon {
        font-size: 1.6rem;
        display: block;
        margin-bottom: 4px;
    }
    
    .vital-item .vital-value {
        font-size: 1.5rem;
        font-weight: 700;
        color: var(--text-primary);
    }
    
    .vital-item .vital-label {
        font-size: 0.7rem;
        color: var(--text-secondary);
        text-transform: uppercase;
        letter-spacing: 0.05em;
        font-weight: 600;
        margin-top: 2px;
    }
    
    .vital-item .vital-unit {
        font-size: 0.6rem;
        color: var(--text-secondary);
    }
    
    .vital-item .vital-normal {
        font-size: 0.55rem;
        color: var(--success);
        margin-top: 2px;
    }
    
    .vital-item .vital-category {
        font-size: 0.6rem;
        font-weight: 700;
        margin-top: 2px;
    }
    
    .vital-item.bmi-item {
        background: var(--primary-bg);
        border-color: var(--primary);
    }
    
    .vital-item.bmi-item .vital-value {
        color: var(--primary);
    }
    
    .vital-notes {
        margin-top: 16px;
        padding-top: 14px;
        border-top: 2px solid var(--border-color);
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
    }
    
    .vital-notes-label {
        font-size: 0.75rem;
        font-weight: 600;
        color: var(--text-secondary);
    }
    
    .vital-notes-text {
        font-size: 0.8rem;
        color: var(--text-primary);
        flex: 1;
    }
    
    /* ================================================================
       INFO GRID
       ================================================================ */
    .info-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
        margin-bottom: 24px;
    }
    
    .info-card {
        background: var(--bg-card);
        border-radius: 16px;
        padding: 20px 24px;
        border: 2px solid var(--border-color);
        transition: all 0.3s ease;
    }
    
    .info-card:hover {
        border-color: var(--primary);
        box-shadow: var(--shadow-md);
    }
    
    .info-card-title {
        font-size: 0.95rem;
        font-weight: 600;
        color: var(--text-primary);
        border-bottom: 2px solid var(--border-color);
        padding-bottom: 10px;
        margin-bottom: 14px;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    .info-card-body {
        display: flex;
        flex-direction: column;
        gap: 6px;
    }
    
    .info-row {
        display: flex;
        justify-content: space-between;
        padding: 4px 0;
        border-bottom: 1px solid var(--border-color);
    }
    
    .info-row:last-child {
        border-bottom: none;
    }
    
    .info-label {
        font-size: 0.8rem;
        color: var(--text-secondary);
        font-weight: 500;
    }
    
    .info-value {
        font-size: 0.85rem;
        color: var(--text-primary);
        text-align: right;
        max-width: 60%;
        word-break: break-word;
    }
    
    .info-value.font-semibold { font-weight: 600; }
    .info-value.font-mono { font-family: monospace; }
    
    .text-blue-600 { color: var(--primary); }
    .text-green-600 { color: #059669; }
    
    /* ================================================================
       BADGES
       ================================================================ */
    .badge {
        padding: 3px 12px;
        border-radius: 20px;
        font-size: 0.7rem;
        font-weight: 600;
        display: inline-flex;
        align-items: center;
        gap: 4px;
        color: #fff;
        border: none;
    }
    
    .badge-success { background: #059669; }
    .badge-danger { background: #EF4444; }
    .badge-warning { background: #D97706; }
    .badge-info { background: var(--primary); }
    
    /* ================================================================
       BUTTONS
       ================================================================ */
    .btn {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 7px 16px;
        border-radius: 8px;
        font-weight: 600;
        font-size: 0.78rem;
        transition: all 0.3s ease;
        cursor: pointer;
        border: none;
        text-decoration: none;
        min-height: 36px;
    }
    
    .btn-outline {
        background: transparent;
        color: var(--text-secondary);
        border: 2px solid var(--border-color);
    }
    .btn-outline:hover {
        background: var(--bg-body);
        border-color: var(--primary);
        color: var(--primary);
        transform: translateY(-2px);
    }
    
    .btn-success {
        background: #059669;
        color: #fff;
        padding: 4px 12px;
        font-size: 0.7rem;
        border-radius: 6px;
        border: none;
        cursor: pointer;
    }
    .btn-success:hover {
        background: #047857;
        transform: scale(1.05);
    }
    
    .btn-danger {
        background: #EF4444;
        color: #fff;
        padding: 4px 12px;
        font-size: 0.7rem;
        border-radius: 6px;
        border: none;
        cursor: pointer;
    }
    .btn-danger:hover {
        background: #DC2626;
        transform: scale(1.05);
    }
    
    .btn-primary {
        background: var(--primary);
        color: white;
        padding: 4px 12px;
        font-size: 0.7rem;
        border-radius: 6px;
        border: none;
        cursor: pointer;
    }
    .btn-primary:hover {
        background: var(--primary-dark);
        transform: scale(1.05);
    }
    
    .btn-sm {
        padding: 4px 10px;
        font-size: 0.7rem;
        border-radius: 6px;
        min-height: 30px;
    }
    
    /* ================================================================
       FOOTER
       ================================================================ */
    .footer {
        padding: 14px 0;
        border-top: 2px solid var(--border-color);
        margin-top: 20px;
        text-align: center;
        font-size: 0.7rem;
        color: var(--text-secondary);
    }
    
    .footer .footer-brand {
        color: var(--primary);
        font-weight: 600;
    }
    
    .text-gray-300 { color: #D1D5DB; }
    .mx-2 { margin-left: 0.5rem; margin-right: 0.5rem; }
    
    /* ================================================================
       DARK MODE
       ================================================================ */
    [data-theme="dark"] .summary-header {
        background: #1E293B;
        border-color: #334155;
    }
    [data-theme="dark"] .summary-title {
        color: #F1F5F9;
    }
    [data-theme="dark"] .meta-item {
        color: #94A3B8;
    }
    [data-theme="dark"] .info-card {
        background: #1E293B;
        border-color: #334155;
    }
    [data-theme="dark"] .info-card-title {
        color: #F1F5F9;
        border-color: #334155;
    }
    [data-theme="dark"] .info-row {
        border-color: #334155;
    }
    [data-theme="dark"] .info-value {
        color: #F1F5F9;
    }
    [data-theme="dark"] .vital-signs-container {
        background: #1E293B;
        border-color: #334155;
    }
    [data-theme="dark"] .vital-signs-title {
        color: #F1F5F9;
    }
    [data-theme="dark"] .vital-item {
        background: #0F172A;
        border-color: #334155;
    }
    [data-theme="dark"] .vital-item .vital-value {
        color: #F1F5F9;
    }
    [data-theme="dark"] .vital-item.bmi-item {
        background: #1E3A5F;
        border-color: #0B5ED7;
    }
    [data-theme="dark"] .vital-notes {
        border-color: #334155;
    }
    [data-theme="dark"] .vital-notes-text {
        color: #F1F5F9;
    }
    [data-theme="dark"] .footer {
        border-color: #334155;
        color: #64748B;
    }
    
    /* ================================================================
       TOAST
       ================================================================ */
    .toast-custom {
        position: fixed;
        bottom: 24px;
        right: 24px;
        padding: 12px 18px;
        border-radius: 12px;
        z-index: 999;
        max-width: 360px;
        transform: translateY(100px);
        opacity: 0;
        transition: all 0.4s ease;
        display: flex;
        align-items: center;
        gap: 10px;
        color: white;
        box-shadow: 0 8px 30px rgba(0,0,0,0.2);
    }
    .toast-custom.show { transform: translateY(0); opacity: 1; }
    .toast-custom.success { background: #059669; }
    .toast-custom.error { background: #EF4444; }
    .toast-custom.info { background: var(--primary); }
    .toast-custom.warning { background: #D97706; }
    
    /* ================================================================
       RESPONSIVE
       ================================================================ */
    @media (max-width: 1024px) {
        .vital-signs-grid {
            grid-template-columns: repeat(3, 1fr);
        }
    }
    
    @media (max-width: 768px) {
        .main-content { margin-left: 0; padding: 16px; }
        .info-grid { grid-template-columns: 1fr; }
        .summary-header { flex-direction: column; align-items: flex-start; padding: 16px 18px; }
        .summary-header-right { align-items: flex-start; width: 100%; }
        .summary-title { font-size: 1.1rem; }
        .summary-meta { flex-direction: column; gap: 4px; }
        .vital-signs-grid { grid-template-columns: repeat(2, 1fr); }
        .vital-signs-header { flex-direction: column; align-items: flex-start; }
        .page-header .page-title { font-size: 1.2rem; }
        .info-card { padding: 14px 16px; }
        .info-row { flex-direction: column; align-items: flex-start; }
        .info-value { text-align: left; max-width: 100%; }
        .btn { font-size: 0.7rem; padding: 4px 10px; }
        .vital-signs-container { padding: 14px 16px; }
        .vital-item { padding: 12px 14px; }
        .vital-item .vital-value { font-size: 1.2rem; }
        .page-subtitle { flex-direction: column; align-items: flex-start; gap: 4px; }
    }
    
    @media (max-width: 480px) {
        .vital-signs-grid { grid-template-columns: 1fr 1fr; }
        .summary-title { font-size: 1rem; }
        .summary-header { padding: 12px 14px; }
        .page-header .page-title { font-size: 1rem; }
        .info-card { padding: 10px 12px; }
        .info-value { font-size: 0.8rem; }
        .status-badge { font-size: 0.7rem; padding: 3px 10px; }
        .branch-tag { font-size: 0.6rem; padding: 2px 10px; }
        .vital-item .vital-value { font-size: 1rem; }
        .vital-item .vital-icon { font-size: 1.2rem; }
    }
    
    @media print {
        .top-nav, .sidebar, .btn, .footer { display: none !important; }
        .main-content { margin: 0 !important; padding: 20px !important; }
        .summary-header, .info-card, .vital-signs-container { 
            border: 1px solid #ddd !important; 
            box-shadow: none !important; 
            page-break-inside: avoid;
        }
        .page-header { border-bottom: 2px solid #0B5ED7 !important; }
        .summary-header { background: white !important; }
        .info-card { background: white !important; }
        .vital-signs-container { background: white !important; }
        .vital-item { background: #f8f9fa !important; }
        .status-badge { background: #0B5ED7 !important; color: white !important; }
        .vital-item.bmi-item { background: #E8F0FE !important; }
    }
</style>

<!-- ================================================================ -->
<!-- JAVASCRIPT -->
<!-- ================================================================ -->
<script>
    // ================================================================
    // DARK MODE - SYNC WITH HEADER
    // ================================================================
    document.addEventListener('darkModeChanged', function(e) {
        var isDark = e.detail && e.detail.isDark;
        var html = document.documentElement;
        
        if (isDark) {
            html.setAttribute('data-theme', 'dark');
        } else {
            html.removeAttribute('data-theme');
        }
    });
    
    if (localStorage.getItem('darkMode') === 'true') {
        document.documentElement.setAttribute('data-theme', 'dark');
    }

    // ================================================================
    // TOAST
    // ================================================================
    function showToast(title, message, type) {
        var toast = document.getElementById('toast');
        var toastTitle = document.getElementById('toastTitle');
        var toastMessage = document.getElementById('toastMessage');
        if (!toast) return;
        toast.className = 'toast-custom ' + type;
        toastTitle.textContent = title;
        toastMessage.textContent = message;
        toast.style.display = 'flex';
        toast.classList.add('show');
        clearTimeout(toast.timeout);
        toast.timeout = setTimeout(function() {
            toast.classList.remove('show');
            setTimeout(function() { toast.style.display = 'none'; }, 400);
        }, 3500);
    }

    // ================================================================
    // DATE & TIME
    // ================================================================
    function updateDateTime() {
        var now = new Date();
        var dateStr = now.toLocaleDateString('en-US', {
            weekday: 'short', month: 'short', day: 'numeric', year: 'numeric'
        });
        var timeStr = now.toLocaleTimeString('en-US', {
            hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true
        });
        var el = document.getElementById('currentDateTime');
        if (el) {
            el.textContent = dateStr + ' • ' + timeStr;
        }
    }
    updateDateTime();
    setInterval(updateDateTime, 1000);

    console.log('%c📅 Appointment Details with Vital Signs', 'font-size:16px; font-weight:bold; color:#0B5ED7;');
    console.log('%c🔐 Session-based login active', 'font-size:12px; color:#34D399;');
    console.log('%c👤 Patient: <?= htmlspecialchars($appointment['patient_name']) ?>', 'font-size:12px; color:#059669;');
    console.log('%c📋 Status: <?= ucfirst($appointment['status'] ?? 'Scheduled') ?>', 'font-size:12px; color:#64748B;');
    console.log('%c💓 Vital Signs: <?= $vital_signs ? '✅ Recorded' : '❌ Not recorded' ?>', 'font-size:12px; color:#DC2626;');
    console.log('%c📊 6 Vital Signs: BP, Weight, Height, Temperature, Pulse, BMI', 'font-size:12px; color:#0B5ED7;');
    console.log('%c👨‍⚕️ Doctor: Dr. <?= htmlspecialchars($doctor_name) ?>', 'font-size:12px; color:#0B5ED7;');
    console.log('%c📦 Using NEW DATABASE: dispensary_db', 'font-size:12px; color:#059669;');
</script>

</body>
</html>