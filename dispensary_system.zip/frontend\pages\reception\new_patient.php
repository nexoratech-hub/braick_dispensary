<?php
// ================================================================
// FILE: frontend/pages/reception/new_patient.php
// RECEPTION - REGISTER NEW PATIENT
// FIXED: visit_type inachukua service_name from services table
// BRAICK DISPENSARY
// ================================================================

session_start();

// ================================================================
// CHECK SESSION - REDIRECT TO LOGIN IF NOT RECEPTION
// ================================================================
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'reception') {
    header('Location: /dispensary_system/frontend/pages/login.php');
    exit;
}

// ================================================================
// GET SESSION DATA
// ================================================================
$user_id = $_SESSION['user_id'];
$full_name = $_SESSION['full_name'] ?? 'Receptionist';
$branch_id = $_SESSION['branch_id'] ?? 1;
$branch_name = $_SESSION['branch_name'] ?? 'Dodoma';
$username = $_SESSION['username'] ?? 'reception';
$profile_pic = $_SESSION['profile_pic'] ?? '';

$user_branch_id = $branch_id;
$selected_branch_id = $branch_id;
$message = '';
$message_type = '';

// Initialize variables
$doctors = [];
$online_doctors = [];
$offline_doctors = [];
$online_doctors_count = 0;
$offline_doctors_count = 0;
$total_doctors = 0;
$latest_patient_id = null;
$latest_visit_id = null;

// ================================================================
// INCLUDE DATABASE
// ================================================================
require_once __DIR__ . '/../../../backend/config/database.php';

try {
    $db = Database::getInstance()->getConnection();
    
    // ================================================================
    // GET UNREAD NOTIFICATIONS COUNT
    // ================================================================
    $unread_notifications = 0;
    try {
        $stmt = $db->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0");
        $stmt->execute([$user_id]);
        $unread_notifications = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
    } catch (Exception $e) {
        $unread_notifications = 0;
    }

    // ================================================================
    // AJAX HANDLER - GET DOCTOR STATUS
    // ================================================================
    if (isset($_POST['action']) && $_POST['action'] === 'get_doctor_status') {
        header('Content-Type: application/json');
        
        $branch_id = isset($_POST['branch_id']) ? (int)$_POST['branch_id'] : $selected_branch_id;
        
        $stmt = $db->prepare("
            SELECT id, full_name, specialty, is_online 
            FROM users 
            WHERE role = 'doctor' AND status = 'active' AND branch_id = ?
            ORDER BY is_online DESC, full_name
        ");
        $stmt->execute([$branch_id]);
        $doctors_list = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $online = [];
        $offline = [];
        $online_count = 0;
        $offline_count = 0;
        
        foreach ($doctors_list as $doc) {
            if ($doc['is_online'] == 1) {
                $online[] = $doc;
                $online_count++;
            } else {
                $offline[] = $doc;
                $offline_count++;
            }
        }
        
        $options_html = '<option value="">-- Select Doctor --</option>';
        
        if ($online_count > 0) {
            $options_html .= '<optgroup label="🟢 Online Doctors (' . $online_count . ')" style="font-weight:600;color:#059669;">';
            foreach ($online as $doc) {
                $options_html .= '<option value="' . $doc['id'] . '" data-online="1" style="font-weight:500;color:#059669;padding:4px;">';
                $options_html .= '🟢 Dr. ' . htmlspecialchars($doc['full_name']);
                if (!empty($doc['specialty'])) {
                    $options_html .= ' (' . htmlspecialchars($doc['specialty']) . ')';
                }
                $options_html .= '</option>';
            }
            $options_html .= '</optgroup>';
        }
        
        if ($offline_count > 0) {
            $options_html .= '<optgroup label="⚪ Offline Doctors (' . $offline_count . ')" style="font-weight:600;color:var(--text-secondary);">';
            foreach ($offline as $doc) {
                $options_html .= '<option value="' . $doc['id'] . '" data-online="0" style="color:var(--text-secondary);padding:4px;">';
                $options_html .= '⚪ Dr. ' . htmlspecialchars($doc['full_name']);
                if (!empty($doc['specialty'])) {
                    $options_html .= ' (' . htmlspecialchars($doc['specialty']) . ')';
                }
                $options_html .= '</option>';
            }
            $options_html .= '</optgroup>';
        }
        
        if (empty($doctors_list)) {
            $options_html .= '<option value="" disabled>No doctors available</option>';
        }
        
        echo json_encode([
            'success' => true,
            'online_count' => $online_count,
            'offline_count' => $offline_count,
            'total_doctors' => count($doctors_list),
            'doctor_options' => $options_html,
            'timestamp' => date('H:i:s')
        ]);
        exit;
    }

    // ================================================================
    // GET DOCTORS
    // ================================================================
    $stmt = $db->prepare("
        SELECT id, full_name, specialty, is_online 
        FROM users 
        WHERE role = 'doctor' AND status = 'active' AND branch_id = ?
        ORDER BY is_online DESC, full_name
    ");
    $stmt->execute([$selected_branch_id]);
    $doctors = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $online_doctors = [];
    $offline_doctors = [];
    $online_doctors_count = 0;
    $offline_doctors_count = 0;
    
    foreach ($doctors as $doc) {
        if ($doc['is_online'] == 1) {
            $online_doctors[] = $doc;
            $online_doctors_count++;
        } else {
            $offline_doctors[] = $doc;
            $offline_doctors_count++;
        }
    }
    $total_doctors = count($doctors);
    
    // ================================================================
    // ✅ GET CONSULTATION SERVICES FROM services TABLE
    // category_id = 2 (Consultation)
    // ================================================================
    $consultation_services = [];
    try {
        $stmt = $db->prepare("
            SELECT id, service_name, description, price, unit, is_active
            FROM services 
            WHERE category_id = 2 AND is_active = 1 
            AND (branch_id = ? OR branch_id IS NULL)
            ORDER BY 
                CASE 
                    WHEN service_name LIKE '%New Patient%' THEN 0
                    WHEN service_name LIKE '%General%' THEN 1
                    WHEN service_name LIKE '%Consultation-B%' THEN 2
                    WHEN service_name LIKE '%Emergency%' THEN 3
                    WHEN service_name LIKE '%Specialist%' THEN 4
                    WHEN service_name LIKE '%Follow%' THEN 5
                    ELSE 6
                END,
                service_name
        ");
        $stmt->execute([$selected_branch_id]);
        $consultation_services = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        $consultation_services = [];
    }
    
    // ================================================================
    // ✅ BUILD VISIT TYPE OPTIONS USING service_id AS KEY
    // ================================================================
    $visit_type_options = [];
    $default_service_id = null;
    $default_price = 0;
    $default_service_name = 'General Consultation';
    $default_key = null;
    
    if (!empty($consultation_services)) {
        foreach ($consultation_services as $service) {
            $service_id = $service['id'];
            $service_name = $service['service_name'];
            $price = (float)($service['price'] ?? 0);
            
            $key = $service_id;
            
            $icon = '🏥';
            if (strpos(strtolower($service_name), 'new patient') !== false) {
                $icon = '🆕';
            } elseif (strpos(strtolower($service_name), 'follow') !== false) {
                $icon = '🔄';
            } elseif (strpos(strtolower($service_name), 'consultation-b') !== false) {
                $icon = '🚨';
            } elseif (strpos(strtolower($service_name), 'emergency') !== false) {
                $icon = '🚨';
            } elseif (strpos(strtolower($service_name), 'specialist') !== false) {
                $icon = '👨‍⚕️';
            }
            
            $visit_type_options[$key] = [
                'service_id' => $service_id,
                'service_name' => $service_name,
                'display_name' => $service_name,
                'price' => $price,
                'unit' => $service['unit'] ?? 'each',
                'description' => $service['description'] ?? '',
                'is_active' => $service['is_active'] ?? 1,
                'icon' => $icon
            ];
            
            // Set default to New Patient or first one
            if (strpos(strtolower($service_name), 'new patient') !== false) {
                $default_service_id = $service_id;
                $default_price = $price;
                $default_service_name = $service_name;
                $default_key = $key;
            } elseif ($default_key === null) {
                $default_service_id = $service_id;
                $default_price = $price;
                $default_service_name = $service_name;
                $default_key = $key;
            }
        }
    }
    
    // ✅ FALLBACK if no services found in database
    if (empty($visit_type_options)) {
        $visit_type_options = [
            1 => [
                'service_id' => null,
                'service_name' => 'New Patient',
                'display_name' => 'New Patient',
                'price' => 10000,
                'unit' => 'each',
                'description' => 'New patient consultation',
                'is_active' => 1,
                'icon' => '🆕'
            ],
            2 => [
                'service_id' => null,
                'service_name' => 'General Consultation',
                'display_name' => 'General Consultation',
                'price' => 15000,
                'unit' => 'each',
                'description' => 'Standard doctor consultation',
                'is_active' => 1,
                'icon' => '🏥'
            ],
            3 => [
                'service_id' => null,
                'service_name' => 'Follow-up Consultation',
                'display_name' => 'Follow-up',
                'price' => 10000,
                'unit' => 'each',
                'description' => 'Follow-up visit',
                'is_active' => 1,
                'icon' => '🔄'
            ],
            4 => [
                'service_id' => null,
                'service_name' => 'Emergency Consultation',
                'display_name' => 'Emergency',
                'price' => 25000,
                'unit' => 'each',
                'description' => 'Emergency visit',
                'is_active' => 1,
                'icon' => '🚨'
            ]
        ];
        $default_key = 1;
        $default_price = 10000;
        $default_service_name = 'New Patient';
    }
    
    // ================================================================
    // ✅ FIXED: Generate UNIQUE patient ID per branch, per year
    // ================================================================
    function generateUniquePatientId($db, $branch_id) {
        $year = date('Y');
        $branch_code = str_pad($branch_id, 2, '0', STR_PAD_LEFT);
        $pattern = "P-$year-$branch_code-%";
        
        $stmt = $db->prepare("
            SELECT patient_id FROM patients 
            WHERE branch_id = ? 
            AND patient_id LIKE ? 
            ORDER BY patient_id DESC 
            LIMIT 1
        ");
        $stmt->execute([$branch_id, $pattern]);
        $last = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($last) {
            $parts = explode('-', $last['patient_id']);
            $last_number = intval(end($parts));
            $next_number = $last_number + 1;
            $new_number = str_pad($next_number, 4, '0', STR_PAD_LEFT);
        } else {
            $new_number = '0001';
        }
        
        $patient_id_number = "P-$year-$branch_code-$new_number";
        
        $stmt = $db->prepare("SELECT COUNT(*) FROM patients WHERE patient_id = ?");
        $stmt->execute([$patient_id_number]);
        $exists = $stmt->fetchColumn();
        
        if ($exists > 0) {
            $counter = 1;
            while ($exists > 0) {
                $new_number = str_pad($next_number + $counter, 4, '0', STR_PAD_LEFT);
                $patient_id_number = "P-$year-$branch_code-$new_number";
                $stmt = $db->prepare("SELECT COUNT(*) FROM patients WHERE patient_id = ?");
                $stmt->execute([$patient_id_number]);
                $exists = $stmt->fetchColumn();
                $counter++;
            }
        }
        
        return $patient_id_number;
    }

    // Generate patient ID
    $patient_id_number = generateUniquePatientId($db, $selected_branch_id);
    
    // ================================================================
    // COMMON SYMPTOMS LIST
    // ================================================================
    $common_symptoms = [
        'Fever' => 'Fever',
        'Headache' => 'Headache',
        'Cough' => 'Cough',
        'Sore Throat' => 'Sore Throat',
        'Body Pain' => 'Body Pain',
        'Fatigue' => 'Fatigue',
        'Nausea' => 'Nausea',
        'Vomiting' => 'Vomiting',
        'Diarrhea' => 'Diarrhea',
        'Chest Pain' => 'Chest Pain',
        'Shortness of Breath' => 'Shortness of Breath',
        'Abdominal Pain' => 'Abdominal Pain',
        'Dizziness' => 'Dizziness',
        'Rash' => 'Rash',
        'Swelling' => 'Swelling'
    ];
    
    // ================================================================
    // COMMON ALLERGIES
    // ================================================================
    $common_allergies = [
        'Penicillin' => 'Penicillin',
        'Sulfa Drugs' => 'Sulfa Drugs',
        'Aspirin' => 'Aspirin',
        'Ibuprofen' => 'Ibuprofen',
        'Codeine' => 'Codeine',
        'Latex' => 'Latex',
        'Peanuts' => 'Peanuts',
        'Shellfish' => 'Shellfish',
        'Eggs' => 'Eggs',
        'Milk' => 'Milk',
        'Wheat' => 'Wheat',
        'Soy' => 'Soy',
        'Dust' => 'Dust',
        'Pollen' => 'Pollen',
        'Animal Dander' => 'Animal Dander'
    ];
    
    // ================================================================
    // MARITAL STATUS
    // ================================================================
    $marital_statuses = [
        'Single' => 'Single',
        'Married' => 'Married',
        'Divorced' => 'Divorced',
        'Widowed' => 'Widowed',
        'Separated' => 'Separated'
    ];
    
    // ================================================================
    // HANDLE FORM SUBMISSION
    // ================================================================
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register_patient'])) {
        $full_name = trim($_POST['full_name'] ?? '');
        $date_of_birth = $_POST['date_of_birth'] ?? null;
        $gender = $_POST['gender'] ?? null;
        $marital_status = $_POST['marital_status'] ?? null;
        $phone = trim($_POST['phone'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $address = trim($_POST['address'] ?? '');
        $emergency_contact = trim($_POST['emergency_contact'] ?? '');
        $blood_group = $_POST['blood_group'] ?? null;
        $allergies = trim($_POST['allergies'] ?? '');
        $branch_id = $selected_branch_id;
        
        $assign_doctor = isset($_POST['assign_doctor']) ? 1 : 0;
        $doctor_id = (int)($_POST['doctor_id'] ?? 0);
        
        // ================================================================
        // ✅ FIXED: Get service_id from POST
        // ================================================================
        $service_id = isset($_POST['visit_type']) ? (int)$_POST['visit_type'] : 0;
        
        // ================================================================
        // ✅ CRITICAL FIX: Fetch service details from database directly
        // ================================================================
        if ($service_id > 0) {
            $stmt = $db->prepare("SELECT id, service_name, price FROM services WHERE id = ? AND is_active = 1");
            $stmt->execute([$service_id]);
            $service = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($service) {
                $visit_type_name = $service['service_name'];  // e.g. "Specialist Consultation"
                $consultation_fee = (float)$service['price']; // 30000
                $service_id_to_store = $service['id'];        // 6
            } else {
                $visit_type_name = 'General Consultation';
                $consultation_fee = 15000;
                $service_id_to_store = null;
                error_log("⚠️ WARNING: Service ID $service_id not found in database");
            }
        } else {
            // Use default if no service selected
            $visit_type_name = 'General Consultation';
            $consultation_fee = 15000;
            $service_id_to_store = null;
        }
        
        $symptoms = trim($_POST['symptoms'] ?? '');
        $complaint = trim($_POST['complaint'] ?? '');
        $notes = trim($_POST['notes'] ?? '');
        
        // ================================================================
        // DEBUG - Log what we have
        // ================================================================
        error_log("=== SERVICE SELECTION DEBUG ===");
        error_log("service_id from POST: " . ($_POST['visit_type'] ?? 'NOT SET'));
        error_log("service_id parsed: " . $service_id);
        error_log("visit_type_name: " . ($visit_type_name ?? 'NULL'));
        error_log("consultation_fee: " . ($consultation_fee ?? 'NULL'));
        error_log("service_id_to_store: " . ($service_id_to_store ?? 'NULL'));
        
        // Validation
        $errors = [];
        if (empty($full_name)) $errors[] = 'Full name is required';
        if (empty($gender)) $errors[] = 'Gender is required';
        if (empty($phone)) $errors[] = 'Phone number is required';
        
        // ================================================================
        // CHECK FOR DUPLICATE PATIENT - PER BRANCH
        // ================================================================
        $duplicate_error = '';
        
        if (empty($errors)) {
            if (!empty($phone)) {
                $stmt = $db->prepare("SELECT id, full_name, patient_id, phone FROM patients WHERE phone = ? AND branch_id = ?");
                $stmt->execute([$phone, $branch_id]);
                $existing = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($existing) {
                    $duplicate_error = "❌ A patient with phone number <strong>" . htmlspecialchars($phone) . "</strong> already exists in <strong>" . htmlspecialchars($branch_name) . "</strong> branch.<br>
                                       👤 Name: <strong>" . htmlspecialchars($existing['full_name']) . "</strong><br>
                                       🆔 ID: <strong>" . htmlspecialchars($existing['patient_id']) . "</strong>";
                }
            }
            
            if (empty($duplicate_error) && !empty($email)) {
                $stmt = $db->prepare("SELECT id, full_name, patient_id, email FROM patients WHERE email = ? AND branch_id = ?");
                $stmt->execute([$email, $branch_id]);
                $existing = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($existing) {
                    $duplicate_error = "❌ A patient with email <strong>" . htmlspecialchars($email) . "</strong> already exists in <strong>" . htmlspecialchars($branch_name) . "</strong> branch.<br>
                                       👤 Name: <strong>" . htmlspecialchars($existing['full_name']) . "</strong><br>
                                       🆔 ID: <strong>" . htmlspecialchars($existing['patient_id']) . "</strong>";
                }
            }
            
            if (empty($duplicate_error) && !empty($full_name) && !empty($phone)) {
                $stmt = $db->prepare("SELECT id, full_name, patient_id, phone FROM patients WHERE full_name = ? AND phone = ? AND branch_id = ?");
                $stmt->execute([$full_name, $phone, $branch_id]);
                $existing = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($existing) {
                    $duplicate_error = "❌ A patient with name <strong>" . htmlspecialchars($full_name) . "</strong> and phone <strong>" . htmlspecialchars($phone) . "</strong> already exists in <strong>" . htmlspecialchars($branch_name) . "</strong> branch.<br>
                                       🆔 ID: <strong>" . htmlspecialchars($existing['patient_id']) . "</strong>";
                }
            }
        }
        
        if (!empty($duplicate_error)) {
            $message = $duplicate_error;
            $message_type = 'error';
        } elseif (empty($errors)) {
            try {
                $db->beginTransaction();
                
                $final_patient_id = generateUniquePatientId($db, $branch_id);
                
                $stmt = $db->prepare("
                    INSERT INTO patients (
                        patient_id, full_name, date_of_birth, gender, phone, email, 
                        address, emergency_contact, blood_group, allergies, branch_id, 
                        created_by, marital_status
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                
                $stmt->execute([
                    $final_patient_id, $full_name, $date_of_birth, $gender, $phone, $email,
                    $address, $emergency_contact, $blood_group, $allergies, $branch_id,
                    $user_id, $marital_status
                ]);
                $patient_db_id = $db->lastInsertId();
                $latest_patient_id = $patient_db_id;
                
                // ================================================================
                // 3. CREATE VISIT - ✅ FIXED
                // ================================================================
                $visit_number = 'VIS-' . date('Ymd') . '-' . str_pad($patient_db_id, 4, '0', STR_PAD_LEFT);
                
                $visit_status = 'pending';
                if ($assign_doctor && $doctor_id > 0) {
                    $visit_status = 'assigned';
                }
                
                // ================================================================
                // ✅ CRITICAL FIX: visit_type = service_name, service_id = id
                // ================================================================
                $consultation_fee_to_store = ($assign_doctor && $doctor_id > 0) ? $consultation_fee : 0;
                
                // Debug log
                error_log("=== SAVING VISIT ===");
                error_log("visit_type_name: " . $visit_type_name);
                error_log("service_id_to_store: " . $service_id_to_store);
                error_log("consultation_fee: " . $consultation_fee);
                
                // ================================================================
                // ✅ INSERT with both visit_type and service_id
                // ================================================================
                $stmt = $db->prepare("
                    INSERT INTO visits (
                        visit_number, 
                        visit_date,
                        patient_id, 
                        receptionist_id, 
                        branch_id, 
                        visit_type,
                        service_id,
                        consultation_fee,
                        status, 
                        doctor_id,
                        symptoms, 
                        complaint, 
                        notes,
                        created_at, 
                        updated_at
                    ) VALUES (?, NOW(), ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
                ");
                $stmt->execute([
                    $visit_number, 
                    $patient_db_id, 
                    $user_id, 
                    $branch_id,
                    $visit_type_name,        // ✅ "Specialist Consultation"
                    $service_id_to_store,     // ✅ 6
                    $consultation_fee_to_store,
                    $visit_status,
                    $assign_doctor && $doctor_id > 0 ? $doctor_id : null,
                    $symptoms,
                    $complaint,
                    $notes
                ]);
                $visit_id = $db->lastInsertId();
                $latest_visit_id = $visit_id;
                
                // ================================================================
                // VERIFY visit_type was saved correctly
                // ================================================================
                $stmt_verify = $db->prepare("SELECT visit_type, service_id, consultation_fee FROM visits WHERE id = ?");
                $stmt_verify->execute([$visit_id]);
                $verify = $stmt_verify->fetch(PDO::FETCH_ASSOC);
                error_log("=== VERIFY SAVED VISIT ===");
                error_log("visit_type saved: " . ($verify['visit_type'] ?? 'NULL'));
                error_log("service_id saved: " . ($verify['service_id'] ?? 'NULL'));
                error_log("consultation_fee saved: " . ($verify['consultation_fee'] ?? 'NULL'));
                
                // ================================================================
                // 4. IF DOCTOR ASSIGNED → CREATE BILL WITH FEE
                // ================================================================
                $bill_created = false;
                $bill_number = null;
                
                if ($assign_doctor && $doctor_id > 0) {
                    $stmt = $db->prepare("UPDATE patients SET assigned_doctor_id = ? WHERE id = ?");
                    $stmt->execute([$doctor_id, $patient_db_id]);
                    
                    $stmt = $db->prepare("UPDATE visits SET assigned_at = NOW() WHERE id = ?");
                    $stmt->execute([$visit_id]);
                    
                    if ($consultation_fee > 0) {
                        $stmt = $db->prepare("
                            SELECT id FROM bills 
                            WHERE visit_id = ? AND status IN ('pending', 'partial')
                            LIMIT 1
                        ");
                        $stmt->execute([$visit_id]);
                        $existing_bill = $stmt->fetch(PDO::FETCH_ASSOC);
                        
                        if (!$existing_bill) {
                            $bill_number = 'BILL-' . date('Ymd') . '-' . str_pad($patient_db_id, 4, '0', STR_PAD_LEFT) . '-' . rand(1000, 9999);
                            
                            $stmt = $db->prepare("
                                INSERT INTO bills (
                                    bill_number, patient_id, visit_id, 
                                    subtotal, discount_amount, total_amount, 
                                    paid_amount, balance, status, 
                                    created_by, branch_id, created_at
                                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?, NOW())
                            ");
                            $stmt->execute([
                                $bill_number,
                                $patient_db_id,
                                $visit_id,
                                $consultation_fee,
                                0,
                                $consultation_fee,
                                0,
                                $consultation_fee,
                                $user_id,
                                $branch_id
                            ]);
                            $bill_id = $db->lastInsertId();
                            
                            $stmt = $db->prepare("
                                INSERT INTO bill_items (
                                    bill_id, patient_id, branch_id,
                                    item_type, item_name, 
                                    quantity, unit_price, total_price, 
                                    status, created_at
                                ) VALUES (?, ?, ?, 'consultation', ?, 1, ?, ?, 'pending', NOW())
                            ");
                            $stmt->execute([
                                $bill_id,
                                $patient_db_id,
                                $branch_id,
                                $visit_type_name,  // ✅ Uses service_name
                                $consultation_fee,
                                $consultation_fee
                            ]);
                            
                            $stmt = $db->prepare("
                                UPDATE visits SET 
                                    visit_total = visit_total + ?,
                                    consultation_fee = ?
                                WHERE id = ?
                            ");
                            $stmt->execute([$consultation_fee, $consultation_fee, $visit_id]);
                            
                            $bill_created = true;
                            
                            try {
                                $stmt = $db->prepare("
                                    SELECT id FROM users 
                                    WHERE role = 'cashier' AND status = 'active' AND branch_id = ?
                                ");
                                $stmt->execute([$branch_id]);
                                $cashiers = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                
                                foreach ($cashiers as $cashier) {
                                    $stmt = $db->prepare("
                                        INSERT INTO notifications (user_id, branch_id, title, message, type, link, is_read, created_at)
                                        VALUES (?, ?, '💰 New Bill Created', ?, 'bill', 'cashier_dashboard.php', 0, NOW())
                                    ");
                                    $stmt->execute([
                                        $cashier['id'],
                                        $branch_id,
                                        "Consultation bill #$bill_number (TSh " . number_format($consultation_fee) . ") for patient " . htmlspecialchars($full_name) . " - " . $visit_type_name
                                    ]);
                                }
                            } catch (Exception $e) {
                                // Silent fail
                            }
                        }
                    }
                }
                
                $db->commit();
                
                $_SESSION['current_patient_id'] = $patient_db_id;
                $_SESSION['current_visit_id'] = $visit_id;
                
                $message = "✅ Patient registered successfully!";
                $message .= "<br>📋 Patient ID: <strong>$final_patient_id</strong>";
                $message .= "<br>📋 Visit #: <strong>$visit_number</strong>";
                $message .= "<br>📋 Visit Type: <strong>" . htmlspecialchars($visit_type_name) . "</strong>";
                $message .= "<br>📋 Service ID: <strong>" . ($service_id_to_store ?? 'N/A') . "</strong>";
                $message .= "<br>📋 Consultation Fee: <strong>TSh " . number_format($consultation_fee, 0) . "</strong>";
                
                if ($assign_doctor && $doctor_id > 0) {
                    $doctor_name = '';
                    foreach ($doctors as $doc) {
                        if ($doc['id'] == $doctor_id) {
                            $doctor_name = $doc['full_name'];
                            break;
                        }
                    }
                    $message .= "<br>👨‍⚕️ Doctor: <strong>Dr. " . htmlspecialchars($doctor_name) . "</strong> (Assigned)";
                    
                    if ($bill_created && $bill_number) {
                        $message .= "<br>💰 Bill: <strong>#$bill_number</strong> (TSh " . number_format($consultation_fee) . ") sent to Cashier!";
                    } elseif ($consultation_fee > 0) {
                        $message .= "<br>💰 Bill created with fee: <strong>TSh " . number_format($consultation_fee) . "</strong>";
                    } else {
                        $message .= "<br>💰 <strong>No bill created</strong> (Fee is zero)";
                    }
                } else {
                    $message .= "<br>⏳ Doctor: <strong>Not assigned</strong> - Patient is in Pending list";
                    $message .= "<br>💰 <strong>No bill created</strong> - Bill will be created when doctor is assigned";
                    $message .= "<br>💡 <em>Tip: Go to Assign Doctor to create bill</em>";
                }
                
                $message_type = 'success';
                
                echo '<script>
                    setTimeout(function(){ 
                        window.location.href = "patients.php?registered=1"; 
                    }, 4000);
                </script>';
                
            } catch (Exception $e) {
                $db->rollBack();
                $message = "❌ Error: " . $e->getMessage();
                $message_type = 'error';
                error_log("Registration error: " . $e->getMessage());
            }
        } else {
            $message = implode('<br>', $errors);
            $message_type = 'error';
        }
    }
    
} catch (Exception $e) {
    $message = "Database error: " . $e->getMessage();
    $message_type = 'error';
    $unread_notifications = 0;
}

// ================================================================
// LOGO PATH
// ================================================================
$logo_path = '/dispensary_system/frontend/assets/uploads/profiles/braick_logo.png';

// ================================================================
// INCLUDE SHARED HEADER & SIDEBAR
// ================================================================
include_once __DIR__ . '/../../components/reception_header.php';
include_once __DIR__ . '/../../components/reception_sidebar.php';
?>
<!DOCTYPE html>
<html lang="en" data-theme="<?= isset($_COOKIE['dark_mode']) && $_COOKIE['dark_mode'] === 'true' ? 'dark' : 'light' ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register New Patient - Braick Dispensary</title>
    
    <link rel="icon" href="<?= $logo_path ?>" type="image/png">
    <link rel="shortcut icon" href="<?= $logo_path ?>" type="image/png">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    
    <style>
        :root {
            --primary: #0B5ED7;
            --primary-dark: #0A4CA8;
            --primary-light: #6EA8FE;
            --primary-bg: #E8F0FE;
            --success: #059669;
            --success-dark: #047857;
            --success-bg: #D1FAE5;
            --danger: #DC2626;
            --danger-dark: #B91C1C;
            --danger-bg: #FEE2E2;
            --warning: #D97706;
            --warning-bg: #FEF3C7;
            --white: #FFFFFF;
            --gray-50: #F8FAFC;
            --gray-100: #F1F5F9;
            --gray-200: #E2E8F0;
            --gray-300: #CBD5E1;
            --gray-400: #94A3B8;
            --gray-500: #64748B;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1E293B;
            --gray-900: #0F172A;
            --shadow-sm: 0 1px 2px rgba(0,0,0,0.05);
            --shadow: 0 1px 3px rgba(0,0,0,0.08);
            --shadow-md: 0 4px 6px rgba(0,0,0,0.07);
            --shadow-lg: 0 10px 15px rgba(0,0,0,0.1);
            --shadow-xl: 0 20px 25px rgba(0,0,0,0.1);
            --bg-body: #F1F5F9;
            --bg-card: #FFFFFF;
            --bg-nav: #FFFFFF;
            --text-primary: #1E293B;
            --text-secondary: #64748B;
            --border-color: #E2E8F0;
        }
        
        [data-theme="dark"] {
            --bg-body: #0F172A;
            --bg-card: #1E293B;
            --bg-nav: #1E293B;
            --text-primary: #F1F5F9;
            --text-secondary: #94A3B8;
            --border-color: #334155;
            --shadow: 0 1px 3px rgba(0,0,0,0.3);
            --shadow-md: 0 4px 12px rgba(0,0,0,0.3);
            --shadow-lg: 0 10px 25px rgba(0,0,0,0.4);
        }
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: 'Inter', 'Segoe UI', -apple-system, sans-serif;
            background: var(--bg-body);
            color: var(--text-primary);
            transition: background 0.3s ease, color 0.3s ease;
        }
        
        ::-webkit-scrollbar { width: 5px; height: 5px; }
        ::-webkit-scrollbar-track { background: var(--bg-body); }
        ::-webkit-scrollbar-thumb { background: var(--primary); border-radius: 10px; }
        
        .top-nav {
            position: fixed;
            top: 0;
            left: 270px;
            right: 0;
            height: 68px;
            background: var(--bg-nav);
            z-index: 40;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 24px;
            border-bottom: 2px solid var(--border-color);
            transition: all 0.3s ease;
        }
        
        .top-nav .search-wrapper {
            display: flex;
            align-items: center;
            background: var(--bg-body);
            border-radius: 10px;
            border: 2px solid var(--border-color);
            transition: all 0.3s;
            flex: 1;
            max-width: 500px;
        }
        
        .top-nav .search-wrapper:focus-within {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(11, 94, 215, 0.15);
        }
        
        .top-nav .search-wrapper input {
            border: none;
            background: transparent;
            padding: 8px 14px;
            width: 100%;
            font-size: 0.85rem;
            outline: none;
            color: var(--text-primary);
        }
        
        .top-nav .search-wrapper input::placeholder {
            color: var(--text-secondary);
        }
        
        .top-nav .search-wrapper .search-btn {
            background: var(--primary);
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 0 10px 10px 0;
            cursor: pointer;
            font-size: 0.85rem;
            transition: all 0.3s;
            white-space: nowrap;
        }
        
        .top-nav .search-wrapper .search-btn:hover {
            background: var(--primary-dark);
        }
        
        .top-nav .datetime {
            font-size: 0.78rem;
            color: var(--text-secondary);
            font-weight: 500;
        }
        
        .top-nav .avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid var(--border-color);
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .top-nav .avatar:hover {
            border-color: var(--primary);
            transform: scale(1.05);
        }
        
        .top-nav .icon-btn {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--text-secondary);
            transition: all 0.3s;
            background: transparent;
            border: none;
            cursor: pointer;
            position: relative;
        }
        
        .top-nav .icon-btn:hover {
            background: var(--bg-body);
            color: var(--primary);
        }
        
        .notif-dot {
            position: absolute;
            top: 6px;
            right: 6px;
            width: 8px;
            height: 8px;
            border-radius: 50%;
            border: 2px solid var(--bg-nav);
            animation: pulse-dot 2s infinite;
        }
        
        .notif-dot.has-notif { background: var(--danger); }
        .notif-dot.no-notif { background: var(--gray-400); animation: none; }
        
        @keyframes pulse-dot {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.2); }
        }
        
        .dark-toggle-btn {
            background: var(--bg-body);
            border: 2px solid var(--border-color);
            border-radius: 10px;
            padding: 6px 12px;
            cursor: pointer;
            font-size: 0.82rem;
            color: var(--text-primary);
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        
        .dark-toggle-btn:hover {
            border-color: var(--primary);
            background: var(--bg-card);
        }
        
        .dark-toggle-btn i { font-size: 0.9rem; }
        
        .main-content {
            margin-left: 270px;
            margin-top: 68px;
            padding: 28px 32px;
            min-height: calc(100vh - 68px);
        }
        
        .page-header {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 16px;
            padding: 24px 32px;
            margin-bottom: 28px;
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            align-items: center;
            gap: 16px;
            box-shadow: 0 4px 20px rgba(11, 94, 215, 0.25);
            position: relative;
            overflow: hidden;
        }
        
        .page-header::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -20%;
            width: 300px;
            height: 300px;
            background: rgba(255,255,255,0.05);
            border-radius: 50%;
            pointer-events: none;
        }
        
        .page-header .page-title {
            color: white;
            font-size: 1.8rem;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
            position: relative;
            z-index: 1;
        }
        
        .page-header .page-title i {
            font-size: 2rem;
            opacity: 0.9;
        }
        
        .page-header .page-subtitle {
            color: rgba(255,255,255,0.85);
            font-size: 0.95rem;
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
            position: relative;
            z-index: 1;
        }
        
        .page-header .page-subtitle strong {
            color: white;
            font-weight: 600;
        }
        
        .page-header .role-badge-display {
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 4px 14px;
            border-radius: 20px;
            font-size: 0.65rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            backdrop-filter: blur(4px);
        }
        
        .page-header .header-badge {
            background: rgba(255,255,255,0.15);
            color: white;
            padding: 4px 14px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 500;
            backdrop-filter: blur(4px);
            display: inline-flex;
            align-items: center;
            gap: 6px;
            border: 1px solid rgba(255,255,255,0.1);
        }
        
        .page-header .header-badge.fee-badge {
            background: rgba(251,191,36,0.2);
            border-color: rgba(251,191,36,0.3);
            color: #FBBF24;
        }
        
        .page-header .btn-outline-light {
            background: rgba(255,255,255,0.15);
            color: white;
            border: 1px solid rgba(255,255,255,0.2);
            padding: 8px 18px;
            border-radius: 10px;
            font-weight: 500;
            font-size: 0.82rem;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            backdrop-filter: blur(4px);
            position: relative;
            z-index: 1;
        }
        
        .page-header .btn-outline-light:hover {
            background: rgba(255,255,255,0.25);
            transform: translateY(-2px);
            box-shadow: 0 4px 16px rgba(0,0,0,0.15);
        }
        
        .update-badge-light {
            background: rgba(255,255,255,0.12);
            color: rgba(255,255,255,0.8);
            padding: 3px 12px;
            border-radius: 20px;
            font-size: 0.6rem;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            backdrop-filter: blur(4px);
        }
        
        .form-card {
            background: var(--bg-card);
            border-radius: 18px;
            padding: 32px 36px;
            border: 1px solid var(--border-color);
            transition: all 0.3s ease;
            max-width: 1100px;
            margin: 0 auto;
            box-shadow: var(--shadow-md);
        }
        
        .form-card:hover {
            border-color: var(--primary);
            box-shadow: 0 8px 30px rgba(11, 94, 215, 0.08);
        }
        
        .form-card .form-header {
            display: flex;
            align-items: center;
            gap: 16px;
            margin-bottom: 28px;
            padding-bottom: 20px;
            border-bottom: 2px solid var(--border-color);
        }
        
        .form-card .form-header .form-icon {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.4rem;
            flex-shrink: 0;
            box-shadow: 0 4px 12px rgba(11, 94, 215, 0.25);
        }
        
        .form-card .form-header .form-title {
            font-size: 1.2rem;
            font-weight: 700;
            color: var(--text-primary);
        }
        
        .form-card .form-header .form-subtitle {
            font-size: 0.8rem;
            color: var(--text-secondary);
            margin-top: 2px;
        }
        
        .form-label {
            font-size: 0.78rem;
            font-weight: 600;
            color: var(--text-primary);
            margin-bottom: 4px;
            display: block;
        }
        
        .form-label .required {
            color: var(--danger);
            margin-left: 2px;
        }
        
        .form-label .label-icon {
            margin-right: 4px;
            color: var(--primary);
        }
        
        .form-control {
            width: 100%;
            padding: 10px 14px;
            border: 2px solid var(--border-color);
            border-radius: 10px;
            font-size: 0.85rem;
            transition: all 0.3s ease;
            outline: none;
            background: var(--bg-card);
            color: var(--text-primary);
        }
        
        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(11, 94, 215, 0.08);
        }
        
        .form-control::placeholder {
            color: var(--text-secondary);
            opacity: 0.5;
        }
        
        .form-row {
            margin-bottom: 18px;
        }
        
        .form-row:last-child {
            margin-bottom: 0;
        }
        
        .form-actions {
            display: flex;
            gap: 12px;
            padding-top: 20px;
            margin-top: 20px;
            border-top: 2px solid var(--border-color);
            flex-wrap: wrap;
        }
        
        select.form-control {
            appearance: auto;
            cursor: pointer;
        }
        
        textarea.form-control {
            resize: vertical;
            min-height: 60px;
        }
        
        .allergy-checkbox-group {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-top: 6px;
        }
        
        .allergy-checkbox-group .allergy-chip {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 4px 14px 4px 10px;
            border-radius: 20px;
            border: 2px solid var(--border-color);
            background: var(--bg-body);
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 0.73rem;
            color: var(--text-secondary);
            user-select: none;
        }
        
        .allergy-checkbox-group .allergy-chip:hover {
            border-color: var(--primary);
            background: var(--primary-bg);
            transform: translateY(-1px);
        }
        
        .allergy-checkbox-group .allergy-chip input[type="checkbox"] {
            display: none;
        }
        
        .allergy-checkbox-group .allergy-chip.active {
            border-color: var(--danger);
            background: var(--danger-bg);
            color: var(--danger-dark);
            box-shadow: 0 2px 8px rgba(220, 38, 38, 0.15);
        }
        
        .assign-doctor-section {
            background: var(--primary-bg);
            border-radius: 14px;
            padding: 20px 24px;
            border: 2px solid var(--primary-light);
            margin-top: 0;
            transition: all 0.3s ease;
        }
        
        .assign-doctor-section:hover {
            border-color: var(--primary);
            box-shadow: 0 4px 16px rgba(11, 94, 215, 0.12);
        }
        
        [data-theme="dark"] .assign-doctor-section {
            background: #1E3A5F;
            border-color: var(--primary);
        }
        
        .assign-doctor-section .section-title {
            font-size: 0.9rem;
            font-weight: 600;
            color: var(--text-primary);
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 14px;
        }
        
        .assign-doctor-section .section-title i {
            color: var(--primary);
        }
        
        .assign-doctor-toggle {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 14px;
            background: var(--bg-card);
            border-radius: 10px;
            border: 2px solid var(--border-color);
            cursor: pointer;
            transition: all 0.3s ease;
            margin-bottom: 14px;
        }
        
        .assign-doctor-toggle:hover {
            border-color: var(--primary);
        }
        
        .assign-doctor-toggle input[type="checkbox"] {
            width: 18px;
            height: 18px;
            accent-color: var(--primary);
            cursor: pointer;
        }
        
        .assign-doctor-toggle .toggle-label {
            font-weight: 500;
            color: var(--text-primary);
            font-size: 0.85rem;
        }
        
        .assign-doctor-toggle .toggle-label i {
            color: var(--primary);
        }
        
        .assign-doctor-toggle .toggle-sub {
            font-size: 0.7rem;
            color: var(--text-secondary);
        }
        
        .assign-doctor-toggle .fee-info {
            margin-left: auto;
            font-size: 0.7rem;
            font-weight: 600;
            color: var(--primary);
            background: var(--primary-bg);
            padding: 2px 12px;
            border-radius: 12px;
        }
        
        .assign-doctor-fields {
            display: none;
            margin-top: 10px;
        }
        
        .assign-doctor-fields.show {
            display: block;
            animation: fadeInUp 0.3s ease forwards;
        }
        
        .doctor-status-badge {
            display: inline-block;
            font-size: 0.6rem;
            padding: 2px 10px;
            border-radius: 12px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .doctor-status-badge.online {
            background: #D1FAE5;
            color: #059669;
            border: 1px solid #34D399;
        }
        
        .doctor-status-badge.offline {
            background: #FEE2E2;
            color: #DC2626;
            border: 1px solid #F87171;
        }
        
        [data-theme="dark"] .doctor-status-badge.online {
            background: #1A3A2A;
            color: #34D399;
            border-color: #34D399;
        }
        
        [data-theme="dark"] .doctor-status-badge.offline {
            background: #3A1A1A;
            color: #F87171;
            border-color: #F87171;
        }
        
        .live-update-indicator {
            display: inline-block;
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: #34D399;
            animation: pulse-dot 1.5s infinite;
            margin-right: 6px;
        }
        
        .live-update-text {
            font-size: 0.6rem;
            color: var(--text-secondary);
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 24px;
            border-radius: 10px;
            font-weight: 600;
            font-size: 0.85rem;
            transition: all 0.3s;
            cursor: pointer;
            border: none;
            text-decoration: none;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            box-shadow: 0 4px 12px rgba(11, 94, 215, 0.25);
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 24px rgba(11, 94, 215, 0.35);
        }
        
        .btn-primary:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }
        
        .btn-outline {
            background: transparent;
            color: var(--text-secondary);
            border: 2px solid var(--border-color);
        }
        
        .btn-outline:hover {
            background: var(--bg-body);
            border-color: var(--primary);
            color: var(--primary);
        }
        
        .role-badge-display {
            display: inline-block;
            font-size: 0.6rem;
            font-weight: 600;
            padding: 2px 10px;
            border-radius: 20px;
            background: var(--primary-bg);
            color: var(--primary);
            text-transform: uppercase;
        }
        
        [data-theme="dark"] .role-badge-display {
            background: #1E3A5F;
            color: #6EA8FE;
        }
        
        .branch-badge-display {
            display: inline-block;
            font-size: 0.6rem;
            font-weight: 600;
            padding: 2px 10px;
            border-radius: 20px;
            background: var(--success-bg);
            color: var(--success);
        }
        
        [data-theme="dark"] .branch-badge-display {
            background: #1A3A2A;
            color: #34D399;
        }
        
        .stat-card {
            background: var(--bg-card);
            border-radius: 14px;
            padding: 16px 20px;
            border: 1px solid var(--border-color);
            text-align: center;
            transition: all 0.3s ease;
            box-shadow: var(--shadow-sm);
        }
        
        .stat-card:hover {
            border-color: var(--primary);
            transform: translateY(-3px);
            box-shadow: var(--shadow-md);
        }
        
        .stat-card .stat-number {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--primary);
        }
        
        .stat-card .stat-label {
            font-size: 0.7rem;
            color: var(--text-secondary);
            font-weight: 500;
        }
        
        .stat-card .stat-icon {
            font-size: 1.4rem;
            margin-bottom: 4px;
        }
        
        .toast-custom {
            position: fixed;
            bottom: 24px;
            right: 24px;
            padding: 14px 20px;
            border-radius: 12px;
            z-index: 999;
            max-width: 400px;
            transform: translateY(100px);
            opacity: 0;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            display: flex;
            align-items: center;
            gap: 12px;
            color: white;
            box-shadow: var(--shadow-lg);
        }
        
        .toast-custom.show {
            transform: translateY(0);
            opacity: 1;
        }
        
        .toast-custom.success { background: var(--success); }
        .toast-custom.error { background: var(--danger); }
        .toast-custom.info { background: var(--primary); }
        .toast-custom.warning { background: var(--warning); }
        
        .footer {
            padding: 14px 0;
            border-top: 1px solid var(--border-color);
            margin-top: 24px;
            text-align: center;
            font-size: 0.7rem;
            color: var(--text-secondary);
        }
        
        .footer .footer-brand { 
            color: var(--primary); 
            font-weight: 600; 
        }
        
        .alert {
            padding: 14px 18px;
            border-radius: 12px;
            margin-bottom: 16px;
            display: flex;
            align-items: flex-start;
            gap: 12px;
            max-width: 1100px;
            margin-left: auto;
            margin-right: auto;
        }
        
        .alert-success {
            background: var(--success-bg);
            color: var(--success-dark);
            border: 1px solid var(--success);
        }
        
        .alert-error {
            background: var(--danger-bg);
            color: var(--danger-dark);
            border: 1px solid var(--danger);
        }
        
        .alert i {
            font-size: 1.1rem;
            margin-top: 2px;
        }
        
        .alert .alert-content {
            flex: 1;
        }
        
        .grid-2 {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 18px;
        }
        
        .grid-full {
            grid-column: 1 / -1;
        }
        
        @media (max-width: 640px) {
            .grid-2 {
                grid-template-columns: 1fr;
                gap: 12px;
            }
        }
        
        .symptom-selector {
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
            margin-top: 6px;
        }
        
        .symptom-chip {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 3px 12px 3px 8px;
            border-radius: 16px;
            border: 2px solid var(--border-color);
            background: var(--bg-body);
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 0.7rem;
            color: var(--text-secondary);
            user-select: none;
        }
        
        .symptom-chip:hover {
            border-color: var(--primary);
            background: var(--primary-bg);
            transform: translateY(-1px);
        }
        
        .symptom-chip.active {
            border-color: var(--primary);
            background: var(--primary-bg);
            color: var(--primary);
        }
        
        @media (max-width: 1024px) {
            .top-nav { left: 0; }
            .main-content { margin-left: 0; padding: 16px; }
            .top-nav .search-wrapper { max-width: 300px; }
            .form-card { padding: 20px; }
        }
        
        @media (max-width: 768px) {
            .top-nav .search-wrapper { max-width: 180px; }
            .top-nav .datetime { display: none; }
            .form-card { padding: 14px; }
            .form-card .form-header .form-title { font-size: 1rem; }
            .page-header { padding: 16px 18px; }
            .page-header .page-title { font-size: 1.3rem; }
            .allergy-checkbox-group .allergy-chip { font-size: 0.65rem; padding: 3px 10px; }
            .assign-doctor-section { padding: 14px 16px; }
        }
        
        @media (max-width: 640px) {
            .main-content { padding: 10px; }
            .top-nav .search-wrapper { max-width: 120px; }
            .top-nav .search-wrapper .search-btn { padding: 8px 10px; font-size: 0.7rem; }
            .form-card { padding: 12px; }
            .form-actions { flex-direction: column; }
            .form-actions .btn { width: 100%; justify-content: center; }
        }
        
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .animate-fade-in-up {
            animation: fadeInUp 0.5s ease forwards;
            opacity: 0;
        }
        
        @keyframes pulse-dot {
            0%, 100% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.5; transform: scale(0.8); }
        }
        
        .fee-info-box {
            background: var(--warning-bg);
            border: 2px solid var(--warning);
            border-radius: 10px;
            padding: 10px 14px;
            margin-top: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.8rem;
            color: var(--warning);
        }
        
        [data-theme="dark"] .fee-info-box {
            background: #3D2E0A;
            border-color: #FBBF24;
            color: #FBBF24;
        }
        
        .fee-info-box i {
            font-size: 1.1rem;
        }
        
        .fee-info-box .fee-amount {
            font-weight: 700;
            font-size: 1rem;
        }
        
        /* Visit type preview */
        .visit-type-preview {
            display: inline-block;
            padding: 4px 14px;
            border-radius: 20px;
            background: var(--primary-bg);
            color: var(--primary);
            font-weight: 600;
            font-size: 0.8rem;
            border: 1px solid var(--primary-light);
        }
        
        /* Service ID badge */
        .service-id-badge {
            display: inline-block;
            font-size: 0.55rem;
            padding: 1px 8px;
            border-radius: 10px;
            background: var(--gray-200);
            color: var(--text-secondary);
            margin-left: 4px;
        }
    </style>
</head>
<body>

<!-- ================================================================ -->
<!-- TOP NAVIGATION -->
<!-- ================================================================ -->
<nav class="top-nav">
    <div class="flex items-center gap-4 flex-1">
        <button id="sidebarToggle" class="lg:hidden icon-btn">
            <i class="fas fa-bars text-lg"></i>
        </button>
        
        <div class="search-wrapper">
            <i class="fas fa-search text-gray-400 ml-3"></i>
            <input type="text" id="searchInput" placeholder="Search patients...">
            <button id="searchBtn" class="search-btn">
                <i class="fas fa-search mr-1"></i> Search
            </button>
        </div>
    </div>
    
    <div class="flex items-center gap-3">
        <span class="branch-badge-display">
            <i class="fas fa-store-alt mr-1"></i> <?= htmlspecialchars($branch_name) ?>
        </span>
        
        <span class="datetime" id="currentDateTime"></span>
        
        <button id="darkModeToggle" class="dark-toggle-btn">
            <i id="darkIcon" class="fas fa-moon"></i>
            <span id="darkText">Dark</span>
        </button>
        
        <button class="icon-btn">
            <i class="fas fa-bell text-lg"></i>
            <span class="notif-dot <?= ($unread_notifications ?? 0) > 0 ? 'has-notif' : 'no-notif' ?>"></span>
        </button>
        
        <a href="profile.php">
            <img src="<?= $logo_path ?>" alt="Profile" class="avatar"
                 onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%2240%22 height=%2240%22%3E%3Crect width=%2240%22 height=%2240%22 fill=%22%230B5ED7%22 rx=%2250%25%22/%3E%3Ctext x=%2220%22 y=%2226%22 text-anchor=%22middle%22 fill=%22white%22 font-size=%2218%22 font-weight=%22bold%22%3E<?= substr($full_name, 0, 1) ?>%3C/text%3E%3C/svg%3E'">
        </a>
    </div>
</nav>

<!-- ================================================================ -->
<!-- MAIN CONTENT -->
<!-- ================================================================ -->
<main class="main-content">

    <!-- ================================================================ -->
    <!-- PAGE HEADER -->
    <!-- ================================================================ -->
    <div class="page-header">
        <div>
            <h1 class="page-title">
                <i class="fas fa-user-plus"></i>
                Register New Patient
                <span class="role-badge-display" style="background:rgba(255,255,255,0.2);color:white;">RECEPTION</span>
            </h1>
            <p class="page-subtitle">
                <i class="fas fa-hospital"></i>
                Create a new patient record in <strong><?= htmlspecialchars($branch_name) ?></strong>
                
                <span class="header-badge">
                    <i class="fas fa-id-card"></i>
                    Next ID: <strong><?= $patient_id_number ?></strong>
                </span>
                
                <span class="header-badge fee-badge">
                    <i class="fas fa-money-bill-wave"></i>
                    Fee: <strong id="headerFeeDisplay">TSh <?= number_format($default_price, 0) ?></strong>
                </span>
                
                <span class="header-badge" style="background:rgba(251,191,36,0.15);border-color:rgba(251,191,36,0.2);color:#FBBF24;">
                    <i class="fas fa-info-circle"></i>
                    Bill only if Doctor Assigned
                </span>
                
                <span class="update-badge-light" id="updateBadge">
                    <i class="fas fa-sync-alt fa-spin"></i> <?= date('H:i:s') ?>
                </span>
            </p>
        </div>
        <div class="header-right">
            <a href="patients.php" class="btn-outline-light">
                <i class="fas fa-arrow-left"></i> Back to Patients
            </a>
        </div>
    </div>

    <!-- Message -->
    <?php if ($message): ?>
        <div class="alert <?= $message_type === 'success' ? 'alert-success' : 'alert-error' ?>">
            <i class="fas <?= $message_type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle' ?>"></i>
            <div class="alert-content"><?= $message ?></div>
        </div>
    <?php endif; ?>

    <!-- ================================================================ -->
    <!-- REGISTRATION FORM -->
    <!-- ================================================================ -->
    <div class="form-card animate-fade-in-up">
        <div class="form-header">
            <div class="form-icon">
                <i class="fas fa-user-plus"></i>
            </div>
            <div>
                <h3 class="form-title">Patient Registration Form</h3>
                <p class="form-subtitle">Fill in the patient details below to complete registration</p>
            </div>
        </div>
        
        <form method="POST" action="" id="registrationForm">
            <!-- ============================================================ -->
            <!-- ROW 1: Full Name (Full Width) -->
            <!-- ============================================================ -->
            <div class="form-row grid-full">
                <label class="form-label">
                    <i class="fas fa-user label-icon"></i> Full Name <span class="required">*</span>
                </label>
                <input type="text" name="full_name" class="form-control" placeholder="Enter full name (e.g. John Doe)" 
                       value="<?= htmlspecialchars($_POST['full_name'] ?? '') ?>" required>
            </div>
            
            <!-- ============================================================ -->
            <!-- ROW 2: Visit Type + Gender -->
            <!-- ============================================================ -->
            <div class="grid-2">
                <div class="form-row">
                    <label class="form-label">
                        <i class="fas fa-tag label-icon"></i> Patient Type <span class="required">*</span>
                    </label>
                    <select name="visit_type" class="form-control" id="visitTypeSelect" required onchange="updateFeeDisplay()">
                        <?php foreach ($visit_type_options as $id => $option): ?>
                            <?php $selected = ($id === $default_key) ? 'selected' : ''; ?>
                            <option value="<?= $id ?>" 
                                    data-price="<?= $option['price'] ?>" 
                                    data-service-name="<?= htmlspecialchars($option['service_name']) ?>"
                                    <?= $selected ?>>
                                <?= $option['icon'] ?? '🏥' ?> <?= htmlspecialchars($option['display_name']) ?> - TSh <?= number_format($option['price'], 0) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <div class="mt-2">
                        <span class="visit-type-preview" id="visitTypePreview">
                            <?= htmlspecialchars($default_service_name) ?>
                        </span>
                    </div>
                </div>
                
                <div class="form-row">
                    <label class="form-label">
                        <i class="fas fa-venus-mars label-icon"></i> Gender <span class="required">*</span>
                    </label>
                    <select name="gender" class="form-control" required>
                        <option value="">Select Gender</option>
                        <option value="Male" <?= ($_POST['gender'] ?? '') === 'Male' ? 'selected' : '' ?>>👨 Male</option>
                        <option value="Female" <?= ($_POST['gender'] ?? '') === 'Female' ? 'selected' : '' ?>>👩 Female</option>
                        <option value="Other" <?= ($_POST['gender'] ?? '') === 'Other' ? 'selected' : '' ?>>⚧ Other</option>
                    </select>
                </div>
            </div>
            
            <!-- ============================================================ -->
            <!-- ROW 3: Marital Status + Date of Birth -->
            <!-- ============================================================ -->
            <div class="grid-2">
                <div class="form-row">
                    <label class="form-label">
                        <i class="fas fa-ring label-icon"></i> Marital Status
                    </label>
                    <select name="marital_status" class="form-control">
                        <option value="">Select Marital Status</option>
                        <?php foreach ($marital_statuses as $key => $label): ?>
                            <option value="<?= $key ?>" <?= ($_POST['marital_status'] ?? '') === $key ? 'selected' : '' ?>>
                                <?= htmlspecialchars($label) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-row">
                    <label class="form-label">
                        <i class="fas fa-calendar label-icon"></i> Date of Birth
                    </label>
                    <input type="date" name="date_of_birth" class="form-control" 
                           value="<?= htmlspecialchars($_POST['date_of_birth'] ?? '') ?>">
                </div>
            </div>
            
            <!-- ============================================================ -->
            <!-- ROW 4: Phone + Email -->
            <!-- ============================================================ -->
            <div class="grid-2">
                <div class="form-row">
                    <label class="form-label">
                        <i class="fas fa-phone label-icon"></i> Phone Number <span class="required">*</span>
                    </label>
                    <input type="tel" name="phone" class="form-control" placeholder="e.g. 0759 154 160" 
                           value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>" required>
                </div>
                
                <div class="form-row">
                    <label class="form-label">
                        <i class="fas fa-envelope label-icon"></i> Email
                    </label>
                    <input type="email" name="email" class="form-control" placeholder="e.g. john@example.com" 
                           value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                </div>
            </div>
            
            <!-- ============================================================ -->
            <!-- ROW 5: Blood Group + Emergency Contact -->
            <!-- ============================================================ -->
            <div class="grid-2">
                <div class="form-row">
                    <label class="form-label">
                        <i class="fas fa-tint label-icon"></i> Blood Group
                    </label>
                    <select name="blood_group" class="form-control">
                        <option value="">Select Blood Group</option>
                        <?php foreach (['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'] as $bg): ?>
                            <option value="<?= $bg ?>" <?= ($_POST['blood_group'] ?? '') === $bg ? 'selected' : '' ?>><?= $bg ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-row">
                    <label class="form-label">
                        <i class="fas fa-phone-alt label-icon"></i> Emergency Contact
                    </label>
                    <input type="tel" name="emergency_contact" class="form-control" placeholder="e.g. 0755 123 456" 
                           value="<?= htmlspecialchars($_POST['emergency_contact'] ?? '') ?>">
                </div>
            </div>
            
            <!-- ============================================================ -->
            <!-- ROW 6: Address (Full Width) -->
            <!-- ============================================================ -->
            <div class="form-row grid-full">
                <label class="form-label">
                    <i class="fas fa-home label-icon"></i> Address
                </label>
                <textarea name="address" class="form-control" placeholder="Enter full address..." rows="2"><?= htmlspecialchars($_POST['address'] ?? '') ?></textarea>
            </div>
            
            <!-- ============================================================ -->
            <!-- ROW 7: Allergies (Full Width) -->
            <!-- ============================================================ -->
            <div class="form-row grid-full">
                <label class="form-label">
                    <i class="fas fa-allergies label-icon"></i> Allergies
                    <span class="text-xs font-normal text-gray-400">(Click to select common allergies)</span>
                </label>
                <div class="allergy-checkbox-group" id="allergyCheckboxGroup">
                    <?php foreach ($common_allergies as $key => $label): ?>
                        <label class="allergy-chip" data-allergy="<?= htmlspecialchars($label) ?>">
                            <input type="checkbox" value="<?= htmlspecialchars($label) ?>" class="allergy-checkbox">
                            <span class="allergy-icon">⚠️</span>
                            <?= htmlspecialchars($label) ?>
                        </label>
                    <?php endforeach; ?>
                </div>
                <textarea name="allergies" id="allergiesTextarea" class="form-control mt-2" placeholder="List any known allergies..." rows="2"><?= htmlspecialchars($_POST['allergies'] ?? '') ?></textarea>
            </div>
            
            <!-- ============================================================ -->
            <!-- ROW 8: ASSIGN DOCTOR SECTION - OPTIONAL -->
            <!-- ============================================================ -->
            <div class="form-row grid-full">
                <div class="assign-doctor-section">
                    <div class="section-title">
                        <i class="fas fa-user-md"></i>
                        Assign Doctor <span style="font-weight:400;font-size:0.8rem;color:var(--text-secondary);">(Optional)</span>
                        <span class="text-xs font-normal text-gray-400">- Bill created only if assigned</span>
                        <span class="live-update-text" style="margin-left:auto;">
                            <span class="live-update-indicator"></span>
                            <span id="doctorUpdateStatus">Updating...</span>
                        </span>
                    </div>
                    
                    <!-- Toggle -->
                    <div class="assign-doctor-toggle" onclick="toggleAssignDoctor(event)">
                        <input type="checkbox" name="assign_doctor" id="assignDoctorCheckbox" value="1" 
                               <?= isset($_POST['assign_doctor']) && $_POST['assign_doctor'] == 1 ? 'checked' : '' ?>
                               onchange="toggleAssignDoctor()">
                        <span class="toggle-label">
                            <i class="fas fa-check-circle"></i> Assign doctor after registration
                        </span>
                        <span class="toggle-sub">(Bill will be created with fee)</span>
                        <span class="fee-info" id="toggleFeeInfo">
                            💰 TSh <span id="toggleFeeAmount"><?= number_format($default_price, 0) ?></span>
                        </span>
                    </div>
                    
                    <!-- Fee Info Box -->
                    <div class="fee-info-box" id="feeInfoBox">
                        <i class="fas fa-info-circle"></i>
                        <span>
                            <strong>Fee: TSh <span id="feeAmountDisplay"><?= number_format($default_price, 0) ?></span></strong>
                            — This fee will be sent to Cashier when doctor is assigned.
                            <span style="font-size:0.7rem;display:block;margin-top:2px;color:var(--text-secondary);">
                                <i class="fas fa-shield-alt"></i> If doctor is not assigned, NO bill will be created.
                            </span>
                        </span>
                    </div>
                    
                    <!-- Doctor Fields -->
                    <div class="assign-doctor-fields <?= (isset($_POST['assign_doctor']) && $_POST['assign_doctor'] == 1) ? 'show' : '' ?>" id="assignDoctorFields">
                        <div class="grid-2">
                            <div class="form-row" style="margin-bottom:0;">
                                <label class="form-label">
                                    <i class="fas fa-user-md label-icon"></i> Select Doctor 
                                    <span id="doctorCountBadge" class="text-xs font-normal text-gray-400">(<?= $online_doctors_count ?> online, <?= $offline_doctors_count ?> offline)</span>
                                </label>
                                <select name="doctor_id" class="form-control" id="doctorSelect">
                                    <option value="">-- Select Doctor --</option>
                                    
                                    <?php if (!empty($online_doctors) && count($online_doctors) > 0): ?>
                                        <optgroup label="🟢 Online Doctors (<?= $online_doctors_count ?>)" style="font-weight:600;color:#059669;">
                                            <?php foreach ($online_doctors as $doctor): ?>
                                                <option value="<?= $doctor['id'] ?>" data-online="1" style="font-weight:500;color:#059669;padding:4px;">
                                                    🟢 Dr. <?= htmlspecialchars($doctor['full_name']) ?>
                                                    <?php if (!empty($doctor['specialty'])): ?>
                                                        (<?= htmlspecialchars($doctor['specialty']) ?>)
                                                    <?php endif; ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </optgroup>
                                    <?php endif; ?>
                                    
                                    <?php if (!empty($offline_doctors) && count($offline_doctors) > 0): ?>
                                        <optgroup label="⚪ Offline Doctors (<?= $offline_doctors_count ?>)" style="font-weight:600;color:var(--text-secondary);">
                                            <?php foreach ($offline_doctors as $doctor): ?>
                                                <option value="<?= $doctor['id'] ?>" data-online="0" style="color:var(--text-secondary);padding:4px;">
                                                    ⚪ Dr. <?= htmlspecialchars($doctor['full_name']) ?>
                                                    <?php if (!empty($doctor['specialty'])): ?>
                                                        (<?= htmlspecialchars($doctor['specialty']) ?>)
                                                    <?php endif; ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </optgroup>
                                    <?php endif; ?>
                                    
                                    <?php if (empty($online_doctors) && empty($offline_doctors)): ?>
                                        <option value="" disabled>No doctors available</option>
                                    <?php endif; ?>
                                </select>
                                
                                <div class="mt-1 text-xs text-gray-400" id="doctorStatusDisplay">
                                    <span class="text-green-500" id="onlineCountDisplay">🟢 <?= $online_doctors_count ?> online</span>
                                    <span class="mx-1">|</span>
                                    <span class="text-gray-500" id="offlineCountDisplay">⚪ <?= $offline_doctors_count ?> offline</span>
                                    <span class="mx-1">|</span>
                                    <span id="lastDoctorUpdate" class="text-gray-400">Updated: <?= date('H:i:s') ?></span>
                                </div>
                            </div>
                            
                            <div class="form-row" style="margin-bottom:0;">
                                <label class="form-label">
                                    <i class="fas fa-money-bill-wave label-icon"></i> Consultation Fee
                                </label>
                                <div style="padding:10px 14px;background:var(--bg-body);border-radius:10px;border:2px solid var(--border-color);">
                                    <span style="font-size:1.1rem;font-weight:700;color:var(--primary);">
                                        TSh <span id="feeDisplay"><?= number_format($default_price, 0) ?></span>
                                    </span>
                                    <span class="text-xs text-gray-400 ml-2">(from selected service)</span>
                                </div>
                            </div>
                        </div>
                        
                        <!-- ============================================================ -->
                        <!-- SYMPTOMS -->
                        <!-- ============================================================ -->
                        <div class="grid-2" style="margin-top:14px;">
                            <div class="form-row" style="margin-bottom:0;">
                                <label class="form-label">
                                    <i class="fas fa-notes-medical label-icon"></i> Symptoms
                                </label>
                                <div class="symptom-selector" id="symptomSelector">
                                    <?php foreach ($common_symptoms as $symptom): ?>
                                        <span class="symptom-chip" data-symptom="<?= htmlspecialchars($symptom) ?>" onclick="toggleSymptom(this)">
                                            <span class="symptom-icon">🩺</span>
                                            <?= htmlspecialchars($symptom) ?>
                                        </span>
                                    <?php endforeach; ?>
                                </div>
                                <textarea name="symptoms" class="form-control mt-2" placeholder="Patient symptoms..." rows="2" id="symptomsTextarea"><?= htmlspecialchars($_POST['symptoms'] ?? '') ?></textarea>
                            </div>
                            <div class="form-row" style="margin-bottom:0;">
                                <label class="form-label">
                                    <i class="fas fa-comment-medical label-icon"></i> Complaint / Reason
                                </label>
                                <textarea name="complaint" class="form-control" placeholder="Main complaint..." rows="2"><?= htmlspecialchars($_POST['complaint'] ?? '') ?></textarea>
                            </div>
                        </div>
                        
                        <!-- Notes -->
                        <div class="form-row grid-full" style="margin-top:10px;margin-bottom:0;">
                            <label class="form-label">
                                <i class="fas fa-sticky-note label-icon"></i> Additional Notes
                            </label>
                            <textarea name="notes" class="form-control" placeholder="Any additional notes..." rows="1"><?= htmlspecialchars($_POST['notes'] ?? '') ?></textarea>
                        </div>
                        
                        <div class="mt-2 text-xs text-gray-400">
                            <i class="fas fa-info-circle mr-1"></i>
                            <?php if (!empty($doctors) && count($doctors) > 0): ?>
                                <span>Patient will be assigned to selected doctor immediately</span>
                                <span class="mx-1">|</span>
                                <span class="text-green-500">✅ Bill will be created and sent to Cashier</span>
                            <?php else: ?>
                                <span class="text-yellow-500">⚠️ No doctors available in this branch</span>
                            <?php endif; ?>
                            <span class="mx-1">|</span>
                            <span>Patient will appear in <strong>Assigned</strong> list</span>
                            <span class="mx-1">|</span>
                            <span class="text-blue-500">
                                <i class="fas fa-shield-alt"></i> Duplicate check: Per Branch
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- ============================================================ -->
            <!-- Hidden Fields -->
            <!-- ============================================================ -->
            <input type="hidden" name="branch_id" value="<?= $selected_branch_id ?>">
            <input type="hidden" name="register_patient" value="1">
            
            <!-- ============================================================ -->
            <!-- FORM ACTIONS -->
            <!-- ============================================================ -->
            <div class="form-actions">
                <button type="submit" class="btn btn-primary" id="registerBtn">
                    <i class="fas fa-save"></i> Register Patient
                </button>
                <button type="reset" class="btn btn-outline" id="resetFormBtn">
                    <i class="fas fa-undo"></i> Reset Form
                </button>
                <a href="patients.php" class="btn btn-outline">
                    <i class="fas fa-times"></i> Cancel
                </a>
            </div>
            
            <!-- ============================================================ -->
            <!-- FOOTER INFO -->
            <!-- ============================================================ -->
            <div class="mt-4 pt-3 text-xs text-gray-400 text-center border-t border-gray-200 dark:border-gray-700">
                <i class="fas fa-info-circle mr-1"></i>
                Patient ID: <strong><?= $patient_id_number ?></strong>
                <span class="mx-2">|</span>
                <i class="fas fa-hashtag mr-1"></i>
                Branch Code: <strong><?= str_pad($selected_branch_id, 2, '0', STR_PAD_LEFT) ?></strong>
                <span class="mx-2">|</span>
                <i class="fas fa-user-md mr-1"></i>
                <span style="color:var(--text-secondary);">Assign doctor is <strong>optional</strong></span>
                <span class="mx-2">|</span>
                <span class="text-green-500">
                    <span class="live-update-indicator"></span> Live
                </span>
                <span class="mx-2">|</span>
                <span class="text-blue-500">
                    <i class="fas fa-shield-alt"></i> Duplicate check: Per Branch
                </span>
                <span class="mx-2">|</span>
                <span class="text-yellow-500">
                    <i class="fas fa-money-bill-wave"></i> Fee: <span id="footerFeeDisplay">TSh <?= number_format($default_price, 0) ?></span>
                </span>
            </div>
        </form>
    </div>

    <!-- ================================================================ -->
    <!-- QUICK STATS -->
    <!-- ================================================================ -->
    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-5" style="max-width:1100px;margin:24px auto 0;">
        <div class="stat-card">
            <div class="stat-icon">📋</div>
            <p class="stat-number text-purple-600"><?= $patient_id_number ?></p>
            <p class="stat-label">Next Patient ID (<?= htmlspecialchars($branch_name) ?>)</p>
        </div>
        <div class="stat-card">
            <div class="stat-icon">👨‍⚕️</div>
            <p class="stat-number text-green-500" id="statOnlineDoctors"><?= $online_doctors_count ?></p>
            <p class="stat-label">Doctors Online</p>
        </div>
        <div class="stat-card">
            <div class="stat-icon">💰</div>
            <p class="stat-number text-yellow-500" id="statDefaultFee"><?= number_format($default_price, 0) ?></p>
            <p class="stat-label">Default Consultation Fee</p>
        </div>
    </div>

    <!-- ================================================================ -->
    <!-- FOOTER -->
    <!-- ================================================================ -->
    <footer class="footer">
        <p>
            <span class="footer-brand">Braick Dispensary</span> Management System
            <span class="text-gray-300 mx-2">|</span>
            Register Patient
            <span class="text-gray-300 mx-2">|</span>
            Logged in as: <strong><?= htmlspecialchars($full_name) ?></strong>
            <span class="text-gray-300 mx-2">|</span>
            Branch: <strong><?= htmlspecialchars($branch_name) ?></strong>
            <span class="text-gray-300 mx-2">|</span>
            <span id="footerTimestamp">Last updated: <?= date('H:i:s') ?></span>
            <span class="text-gray-300 mx-2">|</span>
            &copy; <?= date('Y') ?> All rights reserved
        </p>
    </footer>

</main>

<!-- ================================================================ -->
<!-- TOAST -->
<!-- ================================================================ -->
<div id="toast" class="toast-custom" style="display:none;">
    <i class="fas fa-info-circle" style="font-size:1.1rem;"></i>
    <div>
        <p style="font-weight:600;font-size:0.85rem;margin:0;" id="toastTitle">Notification</p>
        <p style="font-size:0.75rem;opacity:0.9;margin:0;" id="toastMessage"></p>
    </div>
</div>

<!-- ================================================================ -->
<!-- JAVASCRIPT -->
<!-- ================================================================ -->
<script>
    // ================================================================
    // DARK MODE
    // ================================================================
    var darkModeToggle = document.getElementById('darkModeToggle');
    var darkIcon = document.getElementById('darkIcon');
    var darkText = document.getElementById('darkText');
    var htmlElement = document.documentElement;
    
    var savedDarkMode = localStorage.getItem('darkMode');
    if (savedDarkMode === 'true') {
        htmlElement.setAttribute('data-theme', 'dark');
        darkIcon.className = 'fas fa-sun';
        darkText.textContent = 'Light';
    }
    
    darkModeToggle?.addEventListener('click', function() {
        var isDark = htmlElement.getAttribute('data-theme') === 'dark';
        if (isDark) {
            htmlElement.removeAttribute('data-theme');
            darkIcon.className = 'fas fa-moon';
            darkText.textContent = 'Dark';
            localStorage.setItem('darkMode', 'false');
        } else {
            htmlElement.setAttribute('data-theme', 'dark');
            darkIcon.className = 'fas fa-sun';
            darkText.textContent = 'Light';
            localStorage.setItem('darkMode', 'true');
        }
    });

    // ================================================================
    // SIDEBAR TOGGLE
    // ================================================================
    var sidebar = document.getElementById('sidebar');
    var sidebarToggle = document.getElementById('sidebarToggle');
    
    sidebarToggle?.addEventListener('click', function() {
        sidebar.classList.toggle('open');
    });
    
    document.addEventListener('click', function(e) {
        if (window.innerWidth <= 1024) {
            if (!sidebar.contains(e.target) && e.target !== sidebarToggle) {
                sidebar.classList.remove('open');
            }
        }
    });

    // ================================================================
    // DATE & TIME
    // ================================================================
    function updateDateTime() {
        var now = new Date();
        var dateStr = now.toLocaleDateString('en-US', {
            weekday: 'short', month: 'short', day: 'numeric', year: 'numeric'
        });
        var timeStr = now.toLocaleTimeString('en-US', {
            hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true
        });
        document.getElementById('currentDateTime').textContent = dateStr + ' • ' + timeStr;
        document.getElementById('footerTimestamp').textContent = 'Last updated: ' + timeStr;
    }
    updateDateTime();
    setInterval(updateDateTime, 1000);

    // ================================================================
    // SEARCH
    // ================================================================
    var searchBtn = document.getElementById('searchBtn');
    var searchInput = document.getElementById('searchInput');
    
    function performSearch() {
        var query = searchInput.value.trim();
        if (query.length > 0) {
            window.location.href = 'search.php?q=' + encodeURIComponent(query);
        }
    }
    
    searchBtn?.addEventListener('click', performSearch);
    searchInput?.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') performSearch();
    });

    // ================================================================
    // TOAST
    // ================================================================
    function showToast(title, message, type) {
        var toast = document.getElementById('toast');
        var toastTitle = document.getElementById('toastTitle');
        var toastMessage = document.getElementById('toastMessage');
        
        toast.className = 'toast-custom ' + type;
        toastTitle.textContent = title;
        toastMessage.textContent = message;
        toast.style.display = 'flex';
        
        toast.classList.add('show');
        clearTimeout(toast.timeout);
        toast.timeout = setTimeout(function() {
            toast.classList.remove('show');
            setTimeout(function() {
                toast.style.display = 'none';
            }, 400);
        }, 3500);
    }

    // ================================================================
    // ALLERGIES CHECKBOXES
    // ================================================================
    var allergyChips = document.querySelectorAll('.allergy-chip');
    var allergiesTextarea = document.getElementById('allergiesTextarea');
    
    function syncAllergyChips() {
        var currentValue = allergiesTextarea.value;
        var allergyList = currentValue.split(',').map(function(s) { return s.trim(); }).filter(function(s) { return s !== ''; });
        
        allergyChips.forEach(function(chip) {
            var allergyName = chip.dataset.allergy;
            var checkbox = chip.querySelector('.allergy-checkbox');
            
            if (allergyList.includes(allergyName)) {
                chip.classList.add('active');
                checkbox.checked = true;
            } else {
                chip.classList.remove('active');
                checkbox.checked = false;
            }
        });
    }
    
    allergyChips.forEach(function(chip) {
        chip.addEventListener('click', function(e) {
            var checkbox = this.querySelector('.allergy-checkbox');
            var allergyName = this.dataset.allergy;
            
            this.classList.toggle('active');
            checkbox.checked = !checkbox.checked;
            
            var currentValue = allergiesTextarea.value;
            var allergyList = currentValue.split(',').map(function(s) { return s.trim(); }).filter(function(s) { return s !== ''; });
            
            if (checkbox.checked) {
                if (!allergyList.includes(allergyName)) {
                    allergyList.push(allergyName);
                }
            } else {
                allergyList = allergyList.filter(function(item) {
                    return item !== allergyName;
                });
            }
            
            allergiesTextarea.value = allergyList.join(', ');
        });
    });
    
    allergiesTextarea.addEventListener('input', function() {
        syncAllergyChips();
    });
    syncAllergyChips();

    // ================================================================
    // SYMPTOMS SELECTOR
    // ================================================================
    function toggleSymptom(element) {
        var symptom = element.dataset.symptom;
        var textarea = document.getElementById('symptomsTextarea');
        var currentValue = textarea.value;
        var symptomList = currentValue.split(',').map(function(s) { return s.trim(); }).filter(function(s) { return s !== ''; });
        
        element.classList.toggle('active');
        
        if (element.classList.contains('active')) {
            if (!symptomList.includes(symptom)) {
                symptomList.push(symptom);
            }
        } else {
            symptomList = symptomList.filter(function(item) {
                return item !== symptom;
            });
        }
        
        textarea.value = symptomList.join(', ');
    }

    // ================================================================
    // ✅ UPDATE FEE DISPLAY
    // ================================================================
    function updateFeeDisplay() {
        var select = document.getElementById('visitTypeSelect');
        var selectedOption = select.options[select.selectedIndex];
        var price = selectedOption.dataset.price || 0;
        var serviceName = selectedOption.dataset.serviceName || 'Consultation';
        var formattedPrice = parseInt(price).toLocaleString();
        
        // Update all fee displays
        document.getElementById('headerFeeDisplay').textContent = 'TSh ' + formattedPrice;
        document.getElementById('feeDisplay').textContent = formattedPrice;
        document.getElementById('toggleFeeAmount').textContent = formattedPrice;
        document.getElementById('feeAmountDisplay').textContent = formattedPrice;
        document.getElementById('footerFeeDisplay').textContent = 'TSh ' + formattedPrice;
        document.getElementById('statDefaultFee').textContent = formattedPrice;
        
        // Update visit type preview
        var preview = document.getElementById('visitTypePreview');
        if (preview) {
            preview.textContent = serviceName;
            preview.style.display = 'inline-block';
        }
        
        console.log('💰 Service: ' + serviceName + ' | Fee: TSh ' + formattedPrice);
        console.log('📋 Visit Type will be: ' + serviceName);
    }

    // ================================================================
    // TOGGLE ASSIGN DOCTOR
    // ================================================================
    function toggleAssignDoctor(event) {
        var checkbox = document.getElementById('assignDoctorCheckbox');
        var fields = document.getElementById('assignDoctorFields');
        var feeInfoBox = document.getElementById('feeInfoBox');
        
        if (event && event.target && event.target.tagName !== 'INPUT') {
            checkbox.checked = !checkbox.checked;
        }
        
        if (checkbox.checked) {
            fields.classList.add('show');
            feeInfoBox.style.display = 'flex';
        } else {
            fields.classList.remove('show');
            feeInfoBox.style.display = 'none';
        }
    }
    
    // Initial state
    document.addEventListener('DOMContentLoaded', function() {
        var checkbox = document.getElementById('assignDoctorCheckbox');
        var feeInfoBox = document.getElementById('feeInfoBox');
        if (!checkbox.checked) {
            feeInfoBox.style.display = 'none';
        }
        // Initial fee display
        updateFeeDisplay();
    });

    // ================================================================
    // AUTO-UPDATE DOCTOR STATUS - EVERY 3 SECONDS
    // ================================================================
    var doctorUpdateInterval = null;
    var isUpdatingDoctors = false;
    var lastOnlineCount = null;

    function fetchDoctorStatus() {
        if (isUpdatingDoctors) return;
        isUpdatingDoctors = true;
        
        var formData = new FormData();
        formData.append('action', 'get_doctor_status');
        formData.append('branch_id', '<?= $selected_branch_id ?>');
        
        fetch(window.location.href, { 
            method: 'POST', 
            body: formData 
        })
        .then(function(response) { 
            return response.json(); 
        })
        .then(function(data) {
            if (data.success) {
                updateDoctorUI(data);
            }
            isUpdatingDoctors = false;
        })
        .catch(function(error) {
            console.error('Doctor status update error:', error);
            isUpdatingDoctors = false;
        });
    }

    function updateDoctorUI(data) {
        var now = new Date();
        var timeStr = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        
        var onlineCount = document.getElementById('onlineCountDisplay');
        var offlineCount = document.getElementById('offlineCountDisplay');
        var statOnline = document.getElementById('statOnlineDoctors');
        var doctorCountBadge = document.getElementById('doctorCountBadge');
        var lastUpdate = document.getElementById('lastDoctorUpdate');
        var doctorUpdateStatus = document.getElementById('doctorUpdateStatus');
        var updateBadge = document.getElementById('updateBadge');
        
        if (onlineCount) onlineCount.textContent = '🟢 ' + data.online_count + ' online';
        if (offlineCount) offlineCount.textContent = '⚪ ' + data.offline_count + ' offline';
        if (statOnline) statOnline.textContent = data.online_count;
        if (doctorCountBadge) doctorCountBadge.textContent = '(' + data.online_count + ' online, ' + data.offline_count + ' offline)';
        if (lastUpdate) lastUpdate.textContent = 'Updated: ' + timeStr;
        if (doctorUpdateStatus) doctorUpdateStatus.textContent = 'Live ' + timeStr;
        if (updateBadge) updateBadge.innerHTML = '<i class="fas fa-sync-alt fa-spin"></i> ' + timeStr;
        
        // Update doctor select options
        var doctorSelect = document.getElementById('doctorSelect');
        if (doctorSelect && data.doctor_options !== undefined) {
            var currentValue = doctorSelect.value;
            doctorSelect.innerHTML = data.doctor_options;
            if (currentValue) {
                var found = false;
                var options = doctorSelect.querySelectorAll('option');
                options.forEach(function(opt) {
                    if (opt.value == currentValue) found = true;
                });
                if (found) {
                    doctorSelect.value = currentValue;
                }
            }
        }
        
        if (lastOnlineCount !== null && lastOnlineCount !== data.online_count) {
            if (data.online_count > lastOnlineCount) {
                showToast('🟢 Doctor Online', data.online_count + ' doctor(s) are now online', 'success');
            } else if (data.online_count < lastOnlineCount) {
                showToast('⚪ Doctor Offline', (lastOnlineCount - data.online_count) + ' doctor(s) went offline', 'warning');
            }
        }
        lastOnlineCount = data.online_count;
    }

    function startDoctorAutoUpdate() {
        if (doctorUpdateInterval) clearInterval(doctorUpdateInterval);
        setTimeout(function() {
            fetchDoctorStatus();
        }, 1000);
        doctorUpdateInterval = setInterval(fetchDoctorStatus, 3000);
    }

    document.addEventListener('visibilitychange', function() {
        if (document.hidden) {
            if (doctorUpdateInterval) {
                clearInterval(doctorUpdateInterval);
                doctorUpdateInterval = null;
            }
        } else {
            startDoctorAutoUpdate();
        }
    });

    // ================================================================
    // FORM VALIDATION
    // ================================================================
    document.getElementById('registrationForm').addEventListener('submit', function(e) {
        var name = document.querySelector('input[name="full_name"]').value.trim();
        var phone = document.querySelector('input[name="phone"]').value.trim();
        var gender = document.querySelector('select[name="gender"]').value;
        var assignDoctor = document.getElementById('assignDoctorCheckbox').checked;
        
        if (!name) {
            e.preventDefault();
            showToast('Error', 'Please enter patient full name', 'error');
            return false;
        }
        if (!phone) {
            e.preventDefault();
            showToast('Error', 'Please enter phone number', 'error');
            return false;
        }
        if (!gender) {
            e.preventDefault();
            showToast('Error', 'Please select gender', 'error');
            return false;
        }
        
        if (assignDoctor) {
            var doctorSelect = document.getElementById('doctorSelect');
            if (!doctorSelect.value) {
                e.preventDefault();
                showToast('Error', 'Please select a doctor', 'error');
                doctorSelect.focus();
                return false;
            }
        }
        
        var btn = document.getElementById('registerBtn');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Registering...';
    });

    // ================================================================
    // RESET FORM
    // ================================================================
    document.getElementById('resetFormBtn').addEventListener('click', function(e) {
        e.preventDefault();
        
        var form = document.getElementById('registrationForm');
        form.reset();
        
        allergiesTextarea.value = '';
        allergyChips.forEach(function(chip) {
            chip.classList.remove('active');
            var checkbox = chip.querySelector('.allergy-checkbox');
            if (checkbox) checkbox.checked = false;
        });
        
        var symptomChips = document.querySelectorAll('.symptom-chip');
        symptomChips.forEach(function(chip) {
            chip.classList.remove('active');
        });
        document.getElementById('symptomsTextarea').value = '';
        
        var selects = form.querySelectorAll('select');
        selects.forEach(function(select) {
            select.selectedIndex = 0;
        });
        
        // Reset to default visit type
        var visitTypeSelect = document.getElementById('visitTypeSelect');
        var defaultOption = visitTypeSelect.querySelector('option[selected]');
        if (defaultOption) {
            visitTypeSelect.value = defaultOption.value;
        }
        updateFeeDisplay();
        
        var assignCheckbox = document.getElementById('assignDoctorCheckbox');
        var assignFields = document.getElementById('assignDoctorFields');
        var feeInfoBox = document.getElementById('feeInfoBox');
        if (assignCheckbox) assignCheckbox.checked = false;
        if (assignFields) assignFields.classList.remove('show');
        if (feeInfoBox) feeInfoBox.style.display = 'none';
        
        showToast('🔄 Reset', 'Form has been reset successfully', 'info');
    });

    // ================================================================
    // INIT
    // ================================================================
    document.addEventListener('DOMContentLoaded', function() {
        updateFeeDisplay();
        setTimeout(function() {
            startDoctorAutoUpdate();
        }, 2000);
        
        // Listen to visit type change
        document.getElementById('visitTypeSelect').addEventListener('change', function() {
            updateFeeDisplay();
            var selectedOption = this.options[this.selectedIndex];
            var serviceName = selectedOption.dataset.serviceName || 'Consultation';
            var preview = document.getElementById('visitTypePreview');
            if (preview) {
                preview.textContent = serviceName;
            }
        });
        
        console.log('%c👤 Braick - New Patient Registration (FIXED)', 'font-size:18px; font-weight:bold; color:#0B5ED7;');
        console.log('%c✅ Patient ID: UNIQUE per branch, per year', 'font-size:13px; color:#34D399;');
        console.log('%c✅ Format: P-YEAR-BRANCH-XXXX (e.g. P-2026-01-0001)', 'font-size:13px; color:#34D399;');
        console.log('%c✅ visit_type = service_name from services table', 'font-size:13px; color:#FBBF24;');
        console.log('%c✅ service_id = id from services table', 'font-size:13px; color:#0B5ED7;');
        console.log('%c✅ consultation_fee = price from services table', 'font-size:13px; color:#FBBF24;');
        console.log('%c✅ Assign doctor = Bill created & sent to Cashier', 'font-size:13px; color:#34D399;');
        console.log('%c✅ No doctor assigned = No bill (fee=0)', 'font-size:13px; color:#FBBF24;');
        console.log('%c✅ DEBUG: Check error logs for details', 'font-size:13px; color:#EF4444;');
    });
</script>

</body>
</html>