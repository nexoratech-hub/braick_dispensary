<?php
// ================================================================
// FILE: frontend/pages/reception/appointments.php
// RECEPTION - APPOINTMENTS LIST WITH DATE SELECTOR
// ✅ USING NEW DATABASE: dispensary_db
// WITH AUTO-UPDATE (3 SECONDS) - FULL TABLE UPDATE
// BRAICK DISPENSARY
// ================================================================

session_start();

// ================================================================
// CHECK SESSION - REDIRECT TO LOGIN IF NOT RECEPTION
// ================================================================
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'reception') {
    header('Location: /dispensary_system/frontend/pages/login.php');
    exit;
}

// ================================================================
// GET SESSION DATA
// ================================================================
$user_id = $_SESSION['user_id'];
$full_name = $_SESSION['full_name'] ?? 'Receptionist';
$branch_id = $_SESSION['branch_id'] ?? 1;
$branch_name = $_SESSION['branch_name'] ?? 'Dodoma';
$username = $_SESSION['username'] ?? 'reception';
$profile_pic = $_SESSION['profile_pic'] ?? '';

// ================================================================
// INCLUDE DATABASE - NEW DATABASE
// ================================================================
require_once __DIR__ . '/../../../backend/config/database.php';

$selected_branch_id = $branch_id;
$status_filter = $_GET['status'] ?? '';
$date_filter = $_GET['date'] ?? '';
$period_filter = $_GET['period'] ?? '';
$search = $_GET['search'] ?? '';

// ================================================================
// DATE FILTER PERIODS
// ================================================================
if (!empty($period_filter)) {
    switch ($period_filter) {
        case 'today':
            $date_filter = date('Y-m-d');
            break;
        case '1week':
            $date_filter = date('Y-m-d', strtotime('-7 days'));
            break;
        case '1month':
            $date_filter = date('Y-m-d', strtotime('-1 month'));
            break;
        case '3months':
            $date_filter = date('Y-m-d', strtotime('-3 months'));
            break;
        case '6months':
            $date_filter = date('Y-m-d', strtotime('-6 months'));
            break;
        case 'yearly':
            $date_filter = date('Y-m-d', strtotime('-1 year'));
            break;
        case 'all':
        default:
            $date_filter = '';
            $period_filter = 'all';
            break;
    }
}

try {
    $db = Database::getInstance()->getConnection();
    
    // ================================================================
    // GET APPOINTMENTS - FROM NEW DATABASE
    // ================================================================
    $query = "
        SELECT a.*, 
               p.full_name as patient_name, 
               p.patient_id,
               p.id as patient_id,
               u.full_name as doctor_name,
               (
                   SELECT COUNT(*) 
                   FROM appointments 
                   WHERE patient_id = a.patient_id 
                   AND branch_id = ?
               ) as patient_appointment_count
        FROM appointments a
        JOIN patients p ON a.patient_id = p.id
        JOIN users u ON a.doctor_id = u.id
        WHERE a.branch_id = ?
    ";
    $params = [$selected_branch_id, $selected_branch_id];
    
    if (!empty($status_filter)) {
        $query .= " AND a.status = ?";
        $params[] = $status_filter;
    }
    
    if (!empty($date_filter) && $period_filter !== 'all') {
        $query .= " AND DATE(a.appointment_date) >= ?";
        $params[] = $date_filter;
    }
    
    if (!empty($search)) {
        $query .= " AND (p.full_name LIKE ? OR p.patient_id LIKE ? OR u.full_name LIKE ?)";
        $params[] = "%$search%";
        $params[] = "%$search%";
        $params[] = "%$search%";
    }
    
    $query .= " ORDER BY a.appointment_date";
    
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $total_records = count($appointments);
    
    // ================================================================
    // STATUS COUNTS
    // ================================================================
    $status_counts = [];
    $statuses = ['scheduled', 'confirmed', 'in-progress', 'completed', 'cancelled'];
    foreach ($statuses as $status) {
        $sql = "SELECT COUNT(*) as total FROM appointments WHERE status = ? AND branch_id = ?";
        $params_status = [$status, $selected_branch_id];
        
        if (!empty($date_filter) && $period_filter !== 'all') {
            $sql .= " AND DATE(appointment_date) >= ?";
            $params_status[] = $date_filter;
        }
        
        $stmt = $db->prepare($sql);
        $stmt->execute($params_status);
        $status_counts[$status] = $stmt->fetch(PDO::FETCH_ASSOC)['total'] ?? 0;
    }
    
    // Total appointments
    $sql_total = "SELECT COUNT(*) as total FROM appointments WHERE branch_id = ?";
    $params_total = [$selected_branch_id];
    
    if (!empty($date_filter) && $period_filter !== 'all') {
        $sql_total .= " AND DATE(appointment_date) >= ?";
        $params_total[] = $date_filter;
    }
    
    $stmt = $db->prepare($sql_total);
    $stmt->execute($params_total);
    $total_appointments_all = $stmt->fetch(PDO::FETCH_ASSOC)['total'] ?? 0;
    
    // Online doctors
    $stmt = $db->prepare("SELECT COUNT(*) as total FROM users WHERE role = 'doctor' AND is_online = 1 AND status = 'active' AND branch_id = ?");
    $stmt->execute([$selected_branch_id]);
    $online_doctors = $stmt->fetch(PDO::FETCH_ASSOC)['total'] ?? 0;
    
    // Total doctors
    $stmt = $db->prepare("SELECT COUNT(*) as total FROM users WHERE role = 'doctor' AND status = 'active' AND branch_id = ?");
    $stmt->execute([$selected_branch_id]);
    $total_doctors = $stmt->fetch(PDO::FETCH_ASSOC)['total'] ?? 0;
    
    // Unread notifications
    $stmt = $db->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0");
    $stmt->execute([$user_id]);
    $unread_notifications = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
    
} catch (Exception $e) {
    error_log("Appointments error: " . $e->getMessage());
    $appointments = [];
    $status_counts = [];
    $total_records = 0;
    $total_appointments_all = 0;
    $online_doctors = 0;
    $total_doctors = 0;
    $unread_notifications = 0;
}

// ================================================================
// PERIOD LABELS
// ================================================================
$period_labels = [
    'today' => 'Today',
    '1week' => '1 Week',
    '1month' => '1 Month',
    '3months' => '3 Months',
    '6months' => '6 Months',
    'yearly' => 'Yearly',
    'all' => 'All'
];

// ================================================================
// LOGO PATH
// ================================================================
$logo_path = '/dispensary_system/frontend/assets/uploads/profiles/braick_logo.png';

// ================================================================
// INCLUDE SHARED HEADER & SIDEBAR
// ================================================================
include_once __DIR__ . '/../../components/reception_header.php';
include_once __DIR__ . '/../../components/reception_sidebar.php';
?>
<!DOCTYPE html>
<html lang="en" data-theme="<?= isset($_COOKIE['dark_mode']) && $_COOKIE['dark_mode'] === 'true' ? 'dark' : 'light' ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointments - Braick Dispensary</title>
    
    <link rel="icon" href="<?= $logo_path ?>" type="image/png">
    <link rel="shortcut icon" href="<?= $logo_path ?>" type="image/png">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    
    <style>
        :root {
            --primary: #0B5ED7;
            --primary-dark: #0A4CA8;
            --primary-light: #6EA8FE;
            --primary-bg: #E8F0FE;
            --success: #059669;
            --success-dark: #047857;
            --success-bg: #D1FAE5;
            --danger: #DC2626;
            --danger-bg: #FEE2E2;
            --warning: #D97706;
            --warning-bg: #FEF3C7;
            --purple: #7C3AED;
            --purple-bg: #EDE9FE;
            --gray-50: #F8FAFC;
            --gray-100: #F1F5F9;
            --gray-200: #E2E8F0;
            --gray-300: #CBD5E1;
            --gray-400: #94A3B8;
            --gray-500: #64748B;
            --gray-600: #475569;
            --gray-700: #334155;
            --gray-800: #1E293B;
            --gray-900: #0F172A;
            --radius: 10px;
            --radius-lg: 14px;
            --shadow-md: 0 4px 12px rgba(0,0,0,0.08);
            --shadow-lg: 0 8px 30px rgba(0,0,0,0.12);
            --bg-body: #F1F5F9;
            --bg-card: #FFFFFF;
            --bg-nav: #FFFFFF;
            --text-primary: #1E293B;
            --text-secondary: #64748B;
            --border-color: #E2E8F0;
            --table-stripe: #E8F0FE;
            --table-hover: #D1FAE5;
        }
        
        [data-theme="dark"] {
            --bg-body: #0F172A;
            --bg-card: #1E293B;
            --bg-nav: #1E293B;
            --text-primary: #F1F5F9;
            --text-secondary: #94A3B8;
            --border-color: #334155;
            --shadow-md: 0 4px 12px rgba(0,0,0,0.3);
            --shadow-lg: 0 8px 30px rgba(0,0,0,0.4);
            --table-stripe: #1E293B;
            --table-hover: #1A3A2A;
        }
        
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: 'Inter', 'Segoe UI', -apple-system, sans-serif;
            background: var(--bg-body);
            color: var(--text-primary);
            transition: background 0.3s ease, color 0.3s ease;
        }
        
        ::-webkit-scrollbar { width: 5px; height: 5px; }
        ::-webkit-scrollbar-track { background: var(--bg-body); }
        ::-webkit-scrollbar-thumb { background: var(--primary); border-radius: 10px; }
        
        .main-content {
            margin-left: 270px;
            margin-top: 68px;
            padding: 28px 32px;
            min-height: calc(100vh - 68px);
        }
        
        .page-header {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 16px;
            padding: 24px 32px;
            margin-bottom: 28px;
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            align-items: center;
            gap: 16px;
            box-shadow: 0 4px 20px rgba(11, 94, 215, 0.25);
            position: relative;
            overflow: hidden;
        }
        
        .page-header .page-title {
            color: white;
            font-size: 1.6rem;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
            position: relative;
            z-index: 1;
        }
        
        .page-header .page-title i { font-size: 2rem; opacity: 0.9; }
        
        .page-header .page-subtitle {
            color: rgba(255,255,255,0.85);
            font-size: 0.95rem;
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
            position: relative;
            z-index: 1;
        }
        
        .role-badge-display {
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 4px 14px;
            border-radius: 20px;
            font-size: 0.65rem;
            font-weight: 600;
            backdrop-filter: blur(4px);
        }
        
        .header-badge {
            background: rgba(255,255,255,0.15);
            color: white;
            padding: 4px 14px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 500;
            backdrop-filter: blur(4px);
            display: inline-flex;
            align-items: center;
            gap: 6px;
            border: 1px solid rgba(255,255,255,0.1);
        }
        
        .header-badge .online-count { color: #34D399; font-weight: 700; }
        .header-badge .period-badge { color: #FCD34D; font-weight: 600; }
        
        .btn-outline-light {
            background: rgba(255,255,255,0.15);
            color: white;
            border: 1px solid rgba(255,255,255,0.2);
            padding: 8px 18px;
            border-radius: 10px;
            font-weight: 500;
            font-size: 0.82rem;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            backdrop-filter: blur(4px);
        }
        
        .btn-outline-light:hover {
            background: rgba(255,255,255,0.25);
            transform: translateY(-2px);
        }
        
        .update-badge-light {
            background: rgba(255,255,255,0.12);
            color: rgba(255,255,255,0.8);
            padding: 3px 12px;
            border-radius: 20px;
            font-size: 0.6rem;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            backdrop-filter: blur(4px);
        }
        
        .filter-card {
            background: var(--bg-card);
            border-radius: 14px;
            padding: 16px 20px;
            border: 1px solid var(--border-color);
            transition: all 0.3s;
            box-shadow: var(--shadow-sm);
            margin-bottom: 20px;
        }
        
        .filter-card:hover {
            border-color: var(--primary);
            box-shadow: var(--shadow-md);
        }
        
        .filter-btn {
            padding: 4px 14px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 500;
            border: 2px solid var(--border-color);
            background: transparent;
            color: var(--text-secondary);
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
        }
        
        .filter-btn:hover { border-color: var(--primary); color: var(--primary); }
        .filter-btn.active { background: var(--primary); color: white; border-color: var(--primary); }
        
        .filter-group {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 8px;
        }
        
        .filter-group-item {
            display: flex;
            align-items: center;
            gap: 6px;
            flex-wrap: wrap;
        }
        
        .form-control {
            padding: 4px 12px;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            font-size: 0.8rem;
            background: var(--bg-card);
            color: var(--text-primary);
            outline: none;
            transition: all 0.3s;
        }
        
        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(11, 94, 215, 0.1);
        }
        
        .table-card {
            background: var(--bg-card);
            border-radius: 16px;
            border: 1px solid var(--border-color);
            overflow: hidden;
            box-shadow: var(--shadow-sm);
            transition: all 0.3s;
        }
        
        .table-card:hover {
            border-color: var(--primary);
            box-shadow: var(--shadow-md);
        }
        
        .table-card .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px 20px;
            border-bottom: 1px solid var(--border-color);
            flex-wrap: wrap;
            gap: 8px;
        }
        
        .table-card .table-title {
            font-size: 0.9rem;
            font-weight: 600;
            color: var(--text-primary);
        }
        
        .table-card .table-title .title-blue { color: var(--primary); }
        
        .table-wrap-scroll {
            overflow-x: auto;
            overflow-y: auto;
            max-height: 550px;
        }
        
        .data-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.82rem;
            min-width: 800px;
        }
        
        .data-table thead th {
            text-align: left;
            padding: 10px 14px;
            font-weight: 700;
            font-size: 0.65rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: white;
            background: var(--primary);
            border-bottom: 3px solid var(--primary-dark);
            white-space: nowrap;
            position: sticky;
            top: 0;
            z-index: 10;
        }
        
        .data-table td {
            padding: 10px 14px;
            border-bottom: 1px solid var(--border-color);
            color: var(--text-primary);
            vertical-align: middle;
        }
        
        .data-table tbody tr:hover td { background: var(--table-hover); }
        .data-table tbody tr:last-child td { border-bottom: none; }
        
        .table-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 20px;
            border-top: 1px solid var(--border-color);
            flex-wrap: wrap;
            gap: 8px;
        }
        
        .badge {
            padding: 3px 12px;
            border-radius: 20px;
            font-size: 0.65rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            color: white;
            border: none;
        }
        
        .badge-green { background: #059669; color: white; }
        .badge-yellow { background: #D97706; color: white; }
        .badge-red { background: #DC2626; color: white; }
        .badge-blue { background: #0B5ED7; color: white; }
        .badge-gray { background: #94A3B8; color: white; }
        .badge-purple { background: #7C3AED; color: white; }
        
        .appointment-count-badge {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            background: var(--primary-bg);
            color: var(--primary);
            padding: 2px 10px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 600;
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 14px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 0.75rem;
            transition: all 0.3s;
            cursor: pointer;
            border: none;
            text-decoration: none;
        }
        
        .btn-blue { background: var(--primary); color: white; }
        .btn-blue:hover { background: var(--primary-dark); transform: translateY(-1px); box-shadow: 0 4px 12px rgba(11, 94, 215, 0.3); }
        .btn-green { background: var(--success); color: white; }
        .btn-green:hover { background: var(--success-dark); transform: translateY(-1px); box-shadow: 0 4px 12px rgba(5, 150, 105, 0.3); }
        .btn-outline { background: transparent; color: var(--text-secondary); border: 2px solid var(--border-color); }
        .btn-outline:hover { background: var(--bg-body); border-color: var(--primary); color: var(--primary); }
        .btn-sm { padding: 3px 10px; font-size: 0.7rem; border-radius: 6px; }
        
        .stat-card {
            background: var(--bg-card);
            border-radius: 14px;
            padding: 14px 18px;
            border: 1px solid var(--border-color);
            text-align: center;
            transition: all 0.3s ease;
            box-shadow: var(--shadow-sm);
        }
        
        .stat-card:hover {
            border-color: var(--primary);
            transform: translateY(-3px);
            box-shadow: var(--shadow-md);
        }
        
        .stat-card .stat-number { font-size: 1.5rem; font-weight: 700; }
        .stat-card .stat-label { font-size: 0.7rem; color: var(--text-secondary); font-weight: 500; }
        .stat-card .stat-icon { font-size: 1.2rem; margin-bottom: 2px; }
        
        .toast-custom {
            position: fixed;
            bottom: 24px;
            right: 24px;
            padding: 14px 20px;
            border-radius: 12px;
            z-index: 999;
            max-width: 380px;
            transform: translateY(100px);
            opacity: 0;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            display: flex;
            align-items: center;
            gap: 12px;
            color: white;
            box-shadow: var(--shadow-lg);
        }
        
        .toast-custom.show { transform: translateY(0); opacity: 1; }
        .toast-custom.success { background: var(--success); }
        .toast-custom.error { background: var(--danger); }
        .toast-custom.info { background: var(--primary); }
        .toast-custom.warning { background: var(--warning); }
        
        .footer {
            padding: 14px 0;
            border-top: 1px solid var(--border-color);
            margin-top: 24px;
            text-align: center;
            font-size: 0.7rem;
            color: var(--text-secondary);
        }
        
        .footer .footer-brand { color: var(--primary); font-weight: 600; }
        
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .animate-fade-in-up {
            animation: fadeInUp 0.5s ease forwards;
            opacity: 0;
        }
        
        .spinner {
            display: inline-block;
            width: 14px;
            height: 14px;
            border: 2px solid rgba(255,255,255,0.3);
            border-top-color: white;
            border-radius: 50%;
            animation: spin 0.6s linear infinite;
        }
        
        @keyframes spin { to { transform: rotate(360deg); } }
        
        @media (max-width: 1024px) {
            .main-content { margin-left: 0; padding: 16px; }
        }
        
        @media (max-width: 768px) {
            .page-header { padding: 16px 18px; }
            .page-header .page-title { font-size: 1.3rem; }
            .data-table { font-size: 0.7rem; min-width: 700px; }
            .data-table th, .data-table td { padding: 6px 8px; }
            .filter-group { flex-direction: column; align-items: stretch; }
            .filter-group-item { width: 100%; }
            .filter-group-item .form-control { width: 100%; }
        }
        
        @media (max-width: 640px) {
            .main-content { padding: 10px; }
            .data-table { font-size: 0.6rem; min-width: 600px; }
            .data-table th, .data-table td { padding: 4px 6px; }
            .btn-sm { padding: 2px 6px; font-size: 0.55rem; }
            .table-card .table-header { flex-direction: column; align-items: stretch; text-align: center; }
            .table-footer { flex-direction: column; text-align: center; }
            .stat-card .stat-number { font-size: 1.2rem; }
        }
    </style>
</head>
<body>

<!-- ================================================================ -->
<!-- TOP NAVIGATION -->
<!-- ================================================================ -->
<nav class="top-nav">
    <div class="flex items-center gap-4 flex-1">
        <button id="sidebarToggle" class="lg:hidden icon-btn">
            <i class="fas fa-bars text-lg"></i>
        </button>
        
        <div class="search-wrapper">
            <i class="fas fa-search text-gray-400 ml-3"></i>
            <input type="text" id="searchInput" placeholder="Search appointments..." value="<?= htmlspecialchars($search) ?>">
            <button id="searchBtn" class="search-btn">
                <i class="fas fa-search mr-1"></i> Search
            </button>
        </div>
    </div>
    
    <div class="flex items-center gap-3">
        <span class="branch-badge-display" style="display:inline-block;font-size:0.6rem;font-weight:600;padding:2px 10px;border-radius:20px;background:var(--success-bg);color:var(--success);">
            <i class="fas fa-store-alt mr-1"></i> <?= htmlspecialchars($branch_name) ?>
        </span>
        
        <span class="datetime" id="currentDateTime"></span>
        
        <button id="darkModeToggle" class="dark-toggle-btn" style="background:var(--bg-body);border:2px solid var(--border-color);border-radius:10px;padding:6px 12px;cursor:pointer;font-size:0.82rem;color:var(--text-primary);transition:all 0.3s;display:flex;align-items:center;gap:6px;">
            <i id="darkIcon" class="fas fa-moon"></i>
            <span id="darkText">Dark</span>
        </button>
        
        <button class="icon-btn" style="width:38px;height:38px;border-radius:50%;display:flex;align-items:center;justify-content:center;color:var(--text-secondary);transition:all 0.3s;background:transparent;border:none;cursor:pointer;position:relative;">
            <i class="fas fa-bell text-lg"></i>
            <span class="notif-dot <?= ($unread_notifications ?? 0) > 0 ? 'has-notif' : 'no-notif' ?>" style="position:absolute;top:6px;right:6px;width:8px;height:8px;border-radius:50%;border:2px solid var(--bg-nav);animation:<?= ($unread_notifications ?? 0) > 0 ? 'pulse-dot 2s infinite' : 'none' ?>;background:<?= ($unread_notifications ?? 0) > 0 ? 'var(--danger)' : 'var(--gray-400)' ?>;"></span>
        </button>
        
        <a href="profile.php">
            <img src="<?= $logo_path ?>" alt="Profile" class="avatar" style="width:40px;height:40px;border-radius:50%;object-fit:cover;border:2px solid var(--border-color);cursor:pointer;transition:all 0.3s;"
                 onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%2240%22 height=%2240%22%3E%3Crect width=%2240%22 height=%2240%22 fill=%22%230B5ED7%22 rx=%2250%25%22/%3E%3Ctext x=%2220%22 y=%2226%22 text-anchor=%22middle%22 fill=%22white%22 font-size=%2218%22 font-weight=%22bold%22%3E<?= substr($full_name, 0, 1) ?>%3C/text%3E%3C/svg%3E'">
        </a>
    </div>
</nav>

<!-- ================================================================ -->
<!-- MAIN CONTENT -->
<!-- ================================================================ -->
<main class="main-content">

    <!-- Page Header -->
    <div class="page-header">
        <div>
            <h1 class="page-title">
                <i class="fas fa-calendar-check"></i>
                Appointments
                <span class="role-badge-display" style="background:rgba(255,255,255,0.2);color:white;">RECEPTION</span>
                <span class="update-badge-light" id="updateBadge">
                    <i class="fas fa-sync-alt fa-spin"></i> Live
                </span>
            </h1>
            <p class="page-subtitle">
                <i class="fas fa-hospital"></i>
                Manage all patient appointments in <strong><?= htmlspecialchars($branch_name) ?></strong>
                
                <span class="header-badge" id="onlineDoctorBadge">
                    <i class="fas fa-user-md"></i>
                    <span class="online-count" id="onlineDoctorCount"><?= $online_doctors ?></span> Online
                </span>
                
                <span class="header-badge">
                    <i class="fas fa-list"></i>
                    <span id="totalRecordsCount"><?= $total_records ?></span> records
                </span>
                
                <?php if (!empty($period_filter) && $period_filter !== 'all'): ?>
                    <span class="header-badge">
                        <i class="fas fa-calendar-alt"></i>
                        <span class="period-badge">
                            <?= $period_labels[$period_filter] ?? ucfirst($period_filter) ?>
                        </span>
                    </span>
                <?php endif; ?>
            </p>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;position:relative;z-index:1;">
            <a href="new_appointment.php" class="btn-outline-light">
                <i class="fas fa-plus-circle"></i> New Appointment
            </a>
            <button onclick="manualRefresh()" class="btn-outline-light" id="refreshBtn">
                <i class="fas fa-sync-alt"></i> Refresh
            </button>
        </div>
    </div>

    <!-- Filters -->
    <div class="filter-card animate-fade-in-up">
        <div class="filter-group">
            <div class="filter-group-item">
                <span class="text-sm font-medium text-gray-600 dark:text-gray-400 mr-1">Status:</span>
                <a href="appointments.php?period=<?= $period_filter ?>&search=<?= urlencode($search) ?>" 
                   class="filter-btn <?= empty($status_filter) ? 'active' : '' ?>">All (<?= array_sum($status_counts) ?>)</a>
                <?php foreach ($status_counts as $status => $count): ?>
                    <a href="appointments.php?status=<?= $status ?>&period=<?= $period_filter ?>&search=<?= urlencode($search) ?>" 
                       class="filter-btn <?= $status_filter === $status ? 'active' : '' ?>">
                        <?= ucfirst($status) ?> (<?= $count ?>)
                    </a>
                <?php endforeach; ?>
            </div>
            
            <div class="filter-group-item">
                <span class="text-sm font-medium text-gray-600 dark:text-gray-400 mr-1">📆 Period:</span>
                <select id="periodFilter" class="form-control" 
                        onchange="window.location.href='appointments.php?period='+this.value+'&status=<?= $status_filter ?>&search=<?= urlencode($search) ?>'"
                        style="width:auto;min-width:130px;padding:4px 12px;font-size:0.8rem;">
                    <option value="all" <?= $period_filter === 'all' || empty($period_filter) ? 'selected' : '' ?>>📋 All</option>
                    <option value="today" <?= $period_filter === 'today' ? 'selected' : '' ?>>📅 Today</option>
                    <option value="1week" <?= $period_filter === '1week' ? 'selected' : '' ?>>📆 1 Week</option>
                    <option value="1month" <?= $period_filter === '1month' ? 'selected' : '' ?>>📆 1 Month</option>
                    <option value="3months" <?= $period_filter === '3months' ? 'selected' : '' ?>>📆 3 Months</option>
                    <option value="6months" <?= $period_filter === '6months' ? 'selected' : '' ?>>📆 6 Months</option>
                    <option value="yearly" <?= $period_filter === 'yearly' ? 'selected' : '' ?>>📆 Yearly</option>
                </select>
            </div>
            
            <div class="filter-group-item">
                <span class="text-sm font-medium text-gray-600 dark:text-gray-400 mr-1">📅 Date:</span>
                <input type="date" id="datePicker" class="form-control" 
                       value="<?= $date_filter ?>" 
                       onchange="window.location.href='appointments.php?date='+this.value+'&status=<?= $status_filter ?>&search=<?= urlencode($search) ?>'"
                       style="width:auto;min-width:150px;padding:4px 12px;font-size:0.8rem;">
            </div>
        </div>
    </div>

    <!-- Appointments Table -->
    <div class="table-card animate-fade-in-up">
        <div class="table-header">
            <h3 class="table-title">
                <i class="fas fa-list title-blue mr-2"></i> Appointments List
                <span class="text-sm font-normal text-gray-400">(<strong id="recordsCount"><?= $total_records ?></strong> records)</span>
                <span class="text-xs text-gray-400 ml-2" id="lastUpdateTime">⏱ Auto-updating</span>
            </h3>
            <span class="text-xs text-gray-400">Scroll to view all</span>
        </div>
        
        <div class="table-wrap-scroll" id="tableScroll">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Date & Time</th>
                        <th>Patient</th>
                        <th style="text-align:center;">Appointments</th>
                        <th>Doctor</th>
                        <th>Purpose</th>
                        <th>Status</th>
                        <th style="text-align:center;">Actions</th>
                    </tr>
                </thead>
                <tbody id="appointmentsTableBody">
                    <?php if (count($appointments) > 0): ?>
                        <?php $i = 1; foreach ($appointments as $appt): ?>
                            <tr class="appointment-row" data-appointment-id="<?= $appt['id'] ?>">
                                <td><?= $i++ ?></td>
                                <td><?= date('M d, Y h:i A', strtotime($appt['appointment_date'])) ?></td>
                                <td>
                                    <div>
                                        <span class="font-medium"><?= htmlspecialchars($appt['patient_name']) ?></span>
                                        <div class="text-xs text-gray-400"><?= htmlspecialchars($appt['patient_id'] ?? 'N/A') ?></div>
                                    </div>
                                </td>
                                <td style="text-align:center;">
                                    <span class="appointment-count-badge">
                                        <i class="fas fa-calendar-alt"></i> <?= $appt['patient_appointment_count'] ?? 0 ?>
                                    </span>
                                </td>
                                <td>Dr. <?= htmlspecialchars($appt['doctor_name']) ?></td>
                                <td><?= htmlspecialchars($appt['purpose'] ?? 'N/A') ?></td>
                                <td>
                                    <span class="badge <?= $appt['status'] === 'confirmed' || $appt['status'] === 'completed' ? 'badge-green' : ($appt['status'] === 'cancelled' ? 'badge-red' : 'badge-yellow') ?>">
                                        <?= ucfirst($appt['status']) ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="flex gap-1 justify-center">
                                        <a href="view_appointment.php?id=<?= $appt['id'] ?>" 
                                           class="btn btn-blue btn-sm" title="View Appointment">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="view_patient.php?id=<?= $appt['patient_id'] ?>" 
                                           class="btn btn-outline btn-sm" title="View Patient" 
                                           style="border-color:var(--primary);color:var(--primary);">
                                            <i class="fas fa-user"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr id="emptyStateRow">
                            <td colspan="8" class="text-center py-8 text-gray-400">
                                <i class="fas fa-calendar-check text-3xl block mb-2"></i>
                                <?php if (!empty($search) || !empty($status_filter) || !empty($period_filter) || !empty($date_filter)): ?>
                                    No appointments found matching the filters
                                <?php else: ?>
                                    No appointments scheduled
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <div class="table-footer">
            <span class="text-sm text-gray-500">
                <i class="fas fa-calendar-alt mr-1"></i> 
                Showing <strong id="footerRecordsCount"><?= $total_records ?></strong> appointment(s)
            </span>
            <span class="text-sm text-gray-500">
                <i class="fas fa-user mr-1"></i> 
                Branch: <strong><?= htmlspecialchars($branch_name) ?></strong>
            </span>
            <span class="text-sm text-gray-500">
                <i class="fas fa-clock mr-1"></i> 
                <span id="footerTimestamp">Last updated: <?= date('h:i:s A') ?></span>
            </span>
        </div>
    </div>

    <!-- Quick Stats -->
    <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3 mt-5" id="statsContainer">
        <?php foreach ($status_counts as $status => $count): ?>
            <div class="stat-card <?= $status === 'completed' ? 'border-green-500' : ($status === 'cancelled' ? 'border-red-500' : '') ?>" data-status="<?= $status ?>">
                <div class="stat-icon <?= $status === 'completed' ? 'text-green-500' : ($status === 'cancelled' ? 'text-red-500' : 'text-blue-500') ?>">
                    <?php if ($status === 'completed'): ?>
                        <i class="fas fa-check-circle"></i>
                    <?php elseif ($status === 'cancelled'): ?>
                        <i class="fas fa-times-circle"></i>
                    <?php elseif ($status === 'scheduled'): ?>
                        <i class="fas fa-calendar"></i>
                    <?php elseif ($status === 'confirmed'): ?>
                        <i class="fas fa-check"></i>
                    <?php elseif ($status === 'in-progress'): ?>
                        <i class="fas fa-spinner"></i>
                    <?php endif; ?>
                </div>
                <p class="stat-number <?= $status === 'completed' ? 'text-green-600' : ($status === 'cancelled' ? 'text-red-500' : 'text-blue-600') ?> stat-count" data-status="<?= $status ?>">
                    <?= $count ?>
                </p>
                <p class="stat-label capitalize"><?= ucfirst(str_replace('-', ' ', $status)) ?></p>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <p>
            <span class="footer-brand">Braick Dispensary</span> Management System
            <span class="text-gray-300 mx-2">|</span>
            Appointments
            <span class="text-gray-300 mx-2">|</span>
            Logged in as: <strong><?= htmlspecialchars($full_name) ?></strong>
            <span class="text-gray-300 mx-2">|</span>
            Branch: <strong><?= htmlspecialchars($branch_name) ?></strong>
            <span class="text-gray-300 mx-2">|</span>
            &copy; <?= date('Y') ?> All rights reserved
        </p>
    </footer>

</main>

<!-- Toast -->
<div id="toast" class="toast-custom" style="display:none;">
    <i class="fas fa-info-circle"></i>
    <div>
        <p id="toastTitle">Notification</p>
        <p id="toastMessage"></p>
    </div>
</div>

<!-- JavaScript -->
<script>
    // ================================================================
    // DARK MODE
    // ================================================================
    var htmlElement = document.documentElement;
    var savedDarkMode = localStorage.getItem('darkMode');
    if (savedDarkMode === 'true') {
        htmlElement.setAttribute('data-theme', 'dark');
        document.getElementById('darkIcon').className = 'fas fa-sun';
        document.getElementById('darkText').textContent = 'Light';
    }
    
    document.getElementById('darkModeToggle')?.addEventListener('click', function() {
        var isDark = htmlElement.getAttribute('data-theme') === 'dark';
        if (isDark) {
            htmlElement.removeAttribute('data-theme');
            document.getElementById('darkIcon').className = 'fas fa-moon';
            document.getElementById('darkText').textContent = 'Dark';
            localStorage.setItem('darkMode', 'false');
        } else {
            htmlElement.setAttribute('data-theme', 'dark');
            document.getElementById('darkIcon').className = 'fas fa-sun';
            document.getElementById('darkText').textContent = 'Light';
            localStorage.setItem('darkMode', 'true');
        }
    });

    // ================================================================
    // SIDEBAR TOGGLE
    // ================================================================
    var sidebar = document.getElementById('sidebar');
    document.getElementById('sidebarToggle')?.addEventListener('click', function() {
        sidebar.classList.toggle('open');
    });

    // ================================================================
    // DATE & TIME
    // ================================================================
    function updateDateTime() {
        var now = new Date();
        var timeStr = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });
        var el = document.getElementById('currentDateTime');
        if (el) el.textContent = now.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' }) + ' • ' + timeStr;
        var ft = document.getElementById('footerTimestamp');
        if (ft) ft.textContent = 'Last updated: ' + timeStr;
    }
    updateDateTime();
    setInterval(updateDateTime, 1000);

    // ================================================================
    // SEARCH
    // ================================================================
    var searchBtn = document.getElementById('searchBtn');
    var searchInput = document.getElementById('searchInput');
    
    function performSearch() {
        var query = searchInput.value.trim();
        var status = '<?= $status_filter ?>';
        var period = '<?= $period_filter ?>';
        var date = '<?= $date_filter ?>';
        window.location.href = 'appointments.php?search=' + encodeURIComponent(query) + '&status=' + status + '&period=' + period + '&date=' + date;
    }
    
    searchBtn?.addEventListener('click', performSearch);
    searchInput?.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') performSearch();
    });

    // ================================================================
    // TOAST
    // ================================================================
    function showToast(title, message, type) {
        var toast = document.getElementById('toast');
        if (!toast) return;
        toast.className = 'toast-custom ' + type;
        document.getElementById('toastTitle').textContent = title;
        document.getElementById('toastMessage').textContent = message;
        toast.style.display = 'flex';
        toast.classList.add('show');
        clearTimeout(toast.timeout);
        toast.timeout = setTimeout(function() {
            toast.classList.remove('show');
            setTimeout(function() { toast.style.display = 'none'; }, 400);
        }, 3500);
    }

    // ================================================================
    // STATUS BADGE HTML
    // ================================================================
    function getStatusBadge(status) {
        var colorClass = 'badge-yellow';
        if (status === 'confirmed' || status === 'completed') colorClass = 'badge-green';
        else if (status === 'cancelled') colorClass = 'badge-red';
        else if (status === 'scheduled') colorClass = 'badge-blue';
        else if (status === 'in-progress') colorClass = 'badge-purple';
        return '<span class="badge ' + colorClass + '">' + status.charAt(0).toUpperCase() + status.slice(1) + '</span>';
    }

    // ================================================================
    // FETCH APPOINTMENTS DATA
    // ================================================================
    function fetchAppointmentsData() {
        var statusFilter = '<?= $status_filter ?>';
        var periodFilter = '<?= $period_filter ?>';
        var dateFilter = '<?= $date_filter ?>';
        var searchQuery = '<?= addslashes($search) ?>';
        
        var url = '/dispensary_system/frontend/api/get_appointments.php?t=' + new Date().getTime();
        url += '&branch_id=<?= $selected_branch_id ?>';
        if (statusFilter) url += '&status=' + encodeURIComponent(statusFilter);
        if (periodFilter) url += '&period=' + encodeURIComponent(periodFilter);
        if (dateFilter) url += '&date=' + encodeURIComponent(dateFilter);
        if (searchQuery) url += '&search=' + encodeURIComponent(searchQuery);
        
        fetch(url)
            .then(function(response) { return response.json(); })
            .then(function(data) {
                if (data.success) {
                    updateAppointmentsTable(data);
                    updateStatsCounts(data.status_counts || {});
                    updateHeaderCounts(data);
                    
                    var now = new Date();
                    document.getElementById('updateBadge').innerHTML = 
                        '<i class="fas fa-check-circle" style="color:#34D399;"></i> Live ' + 
                        now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
                    document.getElementById('lastUpdateTime').textContent = '⏱ ' + now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
                    
                    if (data.notification) showToast('📋 Update', data.notification, 'info');
                }
            })
            .catch(function(error) { console.error('Fetch appointments error:', error); });
    }

    // ================================================================
    // UPDATE TABLE
    // ================================================================
    function updateAppointmentsTable(data) {
        var tbody = document.getElementById('appointmentsTableBody');
        if (!tbody) return;
        
        var appointments = data.appointments || [];
        var totalRecords = appointments.length;
        
        if (appointments.length === 0) {
            tbody.innerHTML = `
                <tr id="emptyStateRow">
                    <td colspan="8" class="text-center py-8 text-gray-400">
                        <i class="fas fa-calendar-check text-3xl block mb-2"></i>
                        ${data.search || data.status || data.period || data.date ? 'No appointments found matching the filters' : 'No appointments scheduled'}
                    </td>
                </tr>
            `;
            document.getElementById('recordsCount').textContent = '0';
            document.getElementById('footerRecordsCount').textContent = '0';
            document.getElementById('totalRecordsCount').textContent = '0';
            return;
        }
        
        var html = '';
        var counter = 1;
        
        appointments.forEach(function(appt, index) {
            var appointmentDate = new Date(appt.appointment_date);
            var dateStr = appointmentDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
            var timeStr = appointmentDate.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });
            
            html += `
                <tr class="appointment-row" data-appointment-id="${appt.id}">
                    <td>${counter++}</td>
                    <td>${dateStr} ${timeStr}</td>
                    <td>
                        <div>
                            <span class="font-medium">${escapeHtml(appt.patient_name || 'N/A')}</span>
                            <div class="text-xs text-gray-400">${escapeHtml(appt.patient_id || 'N/A')}</div>
                        </div>
                    </td>
                    <td style="text-align:center;">
                        <span class="appointment-count-badge">
                            <i class="fas fa-calendar-alt"></i> ${appt.patient_appointment_count || 0}
                        </span>
                    </td>
                    <td>Dr. ${escapeHtml(appt.doctor_name || 'N/A')}</td>
                    <td>${escapeHtml(appt.purpose || 'N/A')}</td>
                    <td>${getStatusBadge(appt.status || 'scheduled')}</td>
                    <td>
                        <div class="flex gap-1 justify-center">
                            <a href="view_appointment.php?id=${appt.id}" 
                               class="btn btn-blue btn-sm" title="View Appointment">
                                <i class="fas fa-eye"></i>
                            </a>
                            <a href="view_patient.php?id=${appt.patient_id}" 
                               class="btn btn-outline btn-sm" title="View Patient" 
                               style="border-color:var(--primary);color:var(--primary);">
                                <i class="fas fa-user"></i>
                            </a>
                        </div>
                    </td>
                </tr>
            `;
        });
        
        tbody.innerHTML = html;
        document.getElementById('recordsCount').textContent = totalRecords;
        document.getElementById('footerRecordsCount').textContent = totalRecords;
        document.getElementById('totalRecordsCount').textContent = totalRecords;
    }

    // ================================================================
    // UPDATE STATS COUNTS
    // ================================================================
    function updateStatsCounts(statusCounts) {
        var statuses = ['scheduled', 'confirmed', 'in-progress', 'completed', 'cancelled'];
        statuses.forEach(function(status) {
            var count = statusCounts[status] || 0;
            var statElement = document.querySelector('.stat-count[data-status="' + status + '"]');
            if (statElement) statElement.textContent = count;
        });
        
        var total = Object.values(statusCounts).reduce(function(a, b) { return a + b; }, 0);
        var allLink = document.querySelector('.filter-btn:not([href*="status="])');
        if (allLink) {
            var matches = allLink.textContent.match(/\((\d+)\)/);
            if (matches) allLink.textContent = allLink.textContent.replace(/\((\d+)\)/, '(' + total + ')');
        }
    }

    // ================================================================
    // UPDATE HEADER COUNTS
    // ================================================================
    function updateHeaderCounts(data) {
        var onlineCount = data.online_doctors || 0;
        document.getElementById('onlineDoctorCount').textContent = onlineCount;
    }

    // ================================================================
    // ESCAPE HTML
    // ================================================================
    function escapeHtml(text) {
        if (!text) return '';
        var div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // ================================================================
    // START / STOP AUTO-UPDATE
    // ================================================================
    var updateInterval = null;

    function startAutoUpdate() {
        if (updateInterval) clearInterval(updateInterval);
        fetchAppointmentsData();
        updateInterval = setInterval(fetchAppointmentsData, 3000);
    }

    function stopAutoUpdate() {
        if (updateInterval) { clearInterval(updateInterval); updateInterval = null; }
    }

    // ================================================================
    // MANUAL REFRESH
    // ================================================================
    function manualRefresh() {
        var btn = document.getElementById('refreshBtn');
        btn.innerHTML = '<span class="spinner"></span> Loading...';
        btn.disabled = true;
        
        fetchAppointmentsData();
        
        setTimeout(function() {
            btn.innerHTML = '<i class="fas fa-sync-alt"></i> Refresh';
            btn.disabled = false;
            showToast('✅ Refreshed', 'Appointments data updated manually', 'success');
        }, 1500);
    }

    // ================================================================
    // VISIBILITY CHANGE
    // ================================================================
    document.addEventListener('visibilitychange', function() {
        if (document.hidden) stopAutoUpdate();
        else startAutoUpdate();
    });

    // ================================================================
    // KEYBOARD SHORTCUTS
    // ================================================================
    document.addEventListener('keydown', function(e) {
        if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
            e.preventDefault();
            searchInput?.focus();
            searchInput?.select();
        }
        if (e.altKey && e.key === 'n') {
            e.preventDefault();
            window.location.href = 'new_appointment.php';
        }
        if (e.key === 'F5') {
            e.preventDefault();
            manualRefresh();
        }
    });

    // ================================================================
    // INITIALIZE
    // ================================================================
    document.addEventListener('DOMContentLoaded', function() {
        setTimeout(startAutoUpdate, 1500);
    });

    console.log('%c📅 Braick - Appointments List (NEW DATABASE)', 'font-size:18px; font-weight:bold; color:#0B5ED7;');
    console.log('%c✅ USING NEW DATABASE: dispensary_db', 'font-size:13px; color:#34D399;');
    console.log('%c👤 User: <?= htmlspecialchars($full_name) ?>', 'font-size:13px; color:#059669;');
    console.log('%c🏢 Branch: <?= htmlspecialchars($branch_name) ?>', 'font-size:13px; color:#6EA8FE;');
    console.log('%c📊 Total Appointments: <?= $total_appointments_all ?>', 'font-size:13px; color:#64748B;');
    console.log('%c🔄 Full auto-update: Every 3 seconds', 'font-size:13px; color:#34D399;');
</script>

</body>
</html>